/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amprocessselection;
/**
 *
 * @author Yuchu Qin
 * @email: qinyuchu@hud.ac.uk
 * 
 */
public class AMProcessSelection {
    /**
     * @param args the command line arguments
     */
    //Assign values to the TFNs for quantifying the 9 linguistic values
    public interface C {
        public double ALPHAOfVVL = 0.0;
        public double ALPHAOfVL  = 0.0;
        public double ALPHAOfL   = 1.0/8.0;
        public double ALPHAOfSL  = 2.0/8.0;
        public double ALPHAOfM   = 3.0/8.0;
        public double ALPHAOfSH  = 4.0/8.0;
        public double ALPHAOfH   = 5.0/8.0;
        public double ALPHAOfVH  = 6.0/8.0;
        public double ALPHAOfVVH = 7.0/8.0;
    
        public double BETAOfVVL  = 0.0;
        public double BETAOfVL   = 1.0/8.0;
        public double BETAOfL    = 2.0/8.0;
        public double BETAOfSL   = 3.0/8.0;
        public double BETAOfM    = 4.0/8.0;
        public double BETAOfSH   = 5.0/8.0;
        public double BETAOfH    = 6.0/8.0;
        public double BETAOfVH   = 7.0/8.0;
        public double BETAOfVVH  = 1.0;

        public double GAMMAOfVVL = 1.0/8.0;
        public double GAMMAOfVL  = 2.0/8.0;
        public double GAMMAOfL   = 3.0/8.0;
        public double GAMMAOfSL  = 4.0/8.0;
        public double GAMMAOfM   = 5.0/8.0;
        public double GAMMAOfSH  = 6.0/8.0;
        public double GAMMAOfH   = 7.0/8.0;
        public double GAMMAOfVH  = 1.0;
        public double GAMMAOfVVH = 1.0;
    } 
    
    public static void main(String[] args) {
        // TODO code application logic here
        AMProcessSelection amps = new AMProcessSelection();
        //Assign values to columns 1, 2, 3, and 4 of the decision matrix M
        double[] column1 = {120.0, 150.0, 125.0, 185.0, 95.0, 600.0};
        double[] column2 = {6.5, 12.5, 21.0, 20.0, 3.5, 15.5};        
        double[] column3 = {65.0, 40.0, 30.0, 25.0, 30.0, 5.0};
        double[] column4 = {5.0, 8.5, 10.0, 10.0, 6.0, 1.0};
        
        //Compute the ratios of columns 1, 2, 3, and 4 of the fuzzy decision matrix MF
        double[] ratio1 = new double[column1.length];
        double[] ratio2 = new double[column2.length];
        double[] ratio3 = new double[column3.length];
        double[] ratio4 = new double[column4.length];
        ratio1 = amps.RatioOfNV(column1);
        ratio2 = amps.RatioOfNV(column2);
        ratio3 = amps.RatioOfNV(column3);
        ratio4 = amps.RatioOfNV(column4);
        System.out.println("Ratios of Column 1 are as follows:");
        for (int i = 0; i < column1.length; i++) {
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio1[i]));
        }
        System.out.println("Ratios of Column 2 are as follows:");
        for (int i = 0; i < column2.length; i++) {
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio2[i]));
        }
        System.out.println("Ratios of Column 3 are as follows:");
        for (int i = 0; i < column3.length; i++) {
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio3[i]));
        }
        System.out.println("Ratios of Column 4 are as follows:");
        for (int i = 0; i < column4.length; i++) {
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio4[i]));
        }
        
        //Compute the ratios of columns 5 and 6 of the fuzzy decision matrix MF
        double[] alpha5 = {C.ALPHAOfVH, C.ALPHAOfVH, C.ALPHAOfH, C.ALPHAOfSH, C.ALPHAOfVH, C.ALPHAOfVVL};
        double[] beta5 = {C.BETAOfVH, C.BETAOfVH, C.BETAOfH, C.BETAOfSH, C.BETAOfVH, C.BETAOfVVL};
        double[] gamma5 = {C.GAMMAOfVH, C.GAMMAOfVH, C.GAMMAOfH, C.GAMMAOfSH, C.GAMMAOfVH, C.GAMMAOfVVL};
        double[] alpha6 = {C.ALPHAOfM, C.ALPHAOfM, C.ALPHAOfVH, C.ALPHAOfSL, C.ALPHAOfSL, C.ALPHAOfVL};
        double[] beta6 = {C.BETAOfM, C.BETAOfM, C.BETAOfVH, C.BETAOfSL, C.BETAOfSL, C.BETAOfVL};
        double[] gamma6 = {C.GAMMAOfM, C.GAMMAOfM, C.GAMMAOfVH, C.GAMMAOfSL, C.GAMMAOfSL, C.GAMMAOfVL};
        double[] ratio5 = new double[alpha5.length];
        double[] ratio6 = new double[alpha6.length];
        ratio5 = amps.RatioOfLV(alpha5, beta5, gamma5);
        ratio6 = amps.RatioOfLV(alpha6, beta6, gamma6);
        System.out.println("Ratios of Column 5 are as follows:");
        for (int i = 0; i < alpha5.length; i++) {
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio5[i]));
        }
        System.out.println("Ratios of Column 6 are as follows:");
        for (int i = 0; i < alpha6.length; i++) {
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio6[i]));
        }
               
        //Obtain the normalized fuzzy decision matrix MN
        double[][] mu = {
            {1-ratio1[0], 1-ratio2[0], ratio3[0], ratio4[0], 1-ratio5[0], 1-ratio6[0]},
            {1-ratio1[1], 1-ratio2[1], ratio3[1], ratio4[1], 1-ratio5[1], 1-ratio6[1]},
            {1-ratio1[2], 1-ratio2[2], ratio3[2], ratio4[2], 1-ratio5[2], 1-ratio6[2]},
            {1-ratio1[3], 1-ratio2[3], ratio3[3], ratio4[3], 1-ratio5[3], 1-ratio6[3]},
            {1-ratio1[4], 1-ratio2[4], ratio3[4], ratio4[4], 1-ratio5[4], 1-ratio6[4]},
            {1-ratio1[5], 1-ratio2[5], ratio3[5], ratio4[5], 1-ratio5[5], 1-ratio6[5]}
        };
        
        /*double[][] mu = {
            {0.8223, 0.8192, 0.7145, 0.2735, 0.5802, 0.6734},
            {0.7778, 0.6522, 0.4397, 0.4649, 0.5802, 0.6734},
            {0.8148, 0.4158, 0.3298, 0.5470, 0.6401, 0.4285},
            {0.7260, 0.4436, 0.2748, 0.5470, 0.7001, 0.7551},
            {0.8593, 0.9026, 0.3298, 0.3282, 0.5802, 0.7551},
            {0.1113, 0.5688, 0.0550, 0.0547, 0.9800, 0.9184}
        };*/
        
        double[] w = {0.1113, 0.1113, 0.0634, 0.0634, 0.3253, 0.3253};
        //double[] w = {0.3190, 0.3190, 0.1290, 0.1290, 0.0520, 0.0520};
        double[] wA = {0.4000, 0.4000, 0.0500, 0.0500, 0.0500, 0.0500}; 
        double[] wB = {0.0500, 0.0500, 0.4000, 0.4000, 0.0500, 0.0500}; 
        double[] wC = {0.0500, 0.0500, 0.0500, 0.0500, 0.4000, 0.4000}; 
        double[] wD = {0.2250, 0.2250, 0.2250, 0.2250, 0.0500, 0.0500}; 
        double[] wE = {0.2250, 0.2250, 0.0500, 0.0500, 0.2250, 0.2250};
        double[] wF = {0.0500, 0.0500, 0.2250, 0.2250, 0.2250, 0.2250};

        
        double a = 1.0;
        double b = 1.0; 
        int m = 6;
        double lambda = 33.0; 
        double epsilon = 6100.0;
              
        //Compute the aggregation results of each row of MN using the constructed operators
        double[] domOfAggOperator = new double[m];
        //domOfAggOperator = amps.WFAAGBM(m, mu, w, a, b);
        //domOfAggOperator = amps.WFEAGBM(m, mu, w, a, b);
        domOfAggOperator = amps.WFHAGBM(m, mu, w, a, b, lambda);
        //domOfAggOperator = amps.WFFAGBM(m, mu, w, a, b, epsilon);
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.print("domOfAggOperator[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(domOfAggOperator[k]));
        }  
        
        //Sort the aggregation results of each row
        double[] tempArray = new double[m];
        tempArray = amps.SelectionSort(domOfAggOperator);
        
        //Output the rank
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                if (domOfAggOperator[j] == tempArray[i]) {
                    int index = j+1;
                    if (i == m-1) {
                        System.out.print("A[" + index + "]");
                    } else {
                        System.out.print("A[" + index + "] > ");
                    }
                }
            }
        }
    }

    //Define a function to quantify numerical values
    public double[] RatioOfNV(double[] column) {
        double[] ratio = new double[column.length];
        double quadraticSum = 0.0;
        for (int i = 0; i < column.length; i++) {
            quadraticSum = quadraticSum + column[i]*column[i];
        }
        
        for (int j = 0; j < column.length; j++) {
            ratio[j] = column[j]/(Math.pow(quadraticSum, 0.5));
        }       
        return ratio;
    }
    
    //Define a function to quantify linguistic values
    public double[] RatioOfLV(double[] alpha, double[] beta, double[] gamma) {
        double[] ratio = new double[alpha.length];
        double quadraticSumOfGamma = 0.0;
         for (int i = 0; i < gamma.length; i++) {
            quadraticSumOfGamma = quadraticSumOfGamma + gamma[i]*gamma[i];
        }
        for (int j = 0; j < alpha.length; j++) {
            ratio[j] = (1.0/3.0) * ((alpha[j]/(Math.pow(quadraticSumOfGamma, 0.5))) + 
                                    (beta[j]/(Math.pow(quadraticSumOfGamma, 0.5))) + 
                                    (gamma[j]/(Math.pow(quadraticSumOfGamma, 0.5))));                              
        }       
        return ratio;
    }
    
    //Define a function to aggregate each row of MN using the WFAAGBM operator
    public double[] WFAAGBM(int m, double[][] mu, double[] w, double a, double b) {
        double[] resultOfWFAAGBM = new double[m];
        double[] product = new double[m];
        for (int k = 0; k < m; k++) {
            product[k] = 1.0;
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < w.length; i++) {
                for (int j = 0; j < w.length; j++) {
                    if (j != i) {
                        product[k] = product[k] * Math.pow(1 - Math.pow(1 - Math.pow(mu[k][i],w.length*w[i]), a) * 
                                     Math.pow(1 - Math.pow(mu[k][j],w.length*w[j]), b), 1.0/(w.length*(w.length-1)));
                    }
                }
            }
            resultOfWFAAGBM[k] = 1 - Math.pow(1-product[k], 1.0/(a+b));
        }
        return resultOfWFAAGBM;
    }
    
    //Define a function to aggregate each row of MN using the WFEAGBM operator
    public double[] WFEAGBM(int m, double[][] mu, double[] w, double a, double b) {
        double[] resultOfWFEAGBM = new double[m];
        double[][] xki = new double[m][w.length];
        double[][] xkj = new double[m][w.length];
        double[][] yki = new double[m][w.length];
        double[][] ykj = new double[m][w.length];
        double[] mu1 = new double[m];
        double[] mu2 = new double[m];
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < w.length; i++) {
                xki[k][i] = (2*Math.pow(mu[k][i], w.length*w[i]))/(Math.pow(2-mu[k][i], w.length*w[i])+Math.pow(mu[k][i], w.length*w[i]));
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < w.length; j++) {
                xkj[k][j] = (2*Math.pow(mu[k][j], w.length*w[j]))/(Math.pow(2-mu[k][j], w.length*w[j])+Math.pow(mu[k][j], w.length*w[j]));               
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < w.length; i++) {
                yki[k][i] = (Math.pow(1+xki[k][i], a) - Math.pow(1-xki[k][i], a))/(Math.pow(1+xki[k][i], a) + Math.pow(1-xki[k][i], a));               
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < w.length; j++) {
                ykj[k][j] = (Math.pow(1+xkj[k][j], b) - Math.pow(1-xkj[k][j], b))/(Math.pow(1+xkj[k][j], b) + Math.pow(1-xkj[k][j], b));               
            }
        }   
        for (int k = 0; k < m; k++) {
            mu1[k] = 1.0;
            mu2[k] = 1.0;
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < w.length; i++) {
                for (int j = 0; j < w.length; j++) {
                    if (j != i) {
                        mu1[k] = mu1[k] * Math.pow((yki[k][i]+ykj[k][j])/(1+yki[k][i]*ykj[k][j]), 1.0/(w.length*(w.length-1)));
                        mu2[k] = mu2[k] * Math.pow(2-(yki[k][i]+ykj[k][j])/(1+yki[k][i]*ykj[k][j]), 1.0/(w.length*(w.length-1)));                     
                    }
                }
            }
            resultOfWFEAGBM[k] = (Math.pow(3*mu1[k]+mu2[k], 1.0/(a+b)) - Math.pow(mu2[k]-mu1[k], 1.0/(a+b)))/
                                 (Math.pow(3*mu1[k]+mu2[k], 1.0/(a+b)) + Math.pow(mu2[k]-mu1[k], 1.0/(a+b)));
        }
        return resultOfWFEAGBM;      
    }
    
    //Define a function to aggregate each row of MN using the WFHAGBM operator
    public double[] WFHAGBM(int m, double[][] mu, double[] w, double a, double b, double lambda) {
        double[] resultOfWFHAGBM = new double[m];
        double[][] xki = new double[m][w.length];
        double[][] xkj = new double[m][w.length];
        double[][] yki = new double[m][w.length];
        double[][] ykj = new double[m][w.length];       
        double[] mu1 = new double[m];
        double[] mu2 = new double[m];       
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < w.length; i++) {
                xki[k][i] = (lambda*Math.pow(mu[k][i], w.length*w[i]))/
                            ((lambda-1)*Math.pow(mu[k][i], w.length*w[i]) + Math.pow(1+(lambda-1)*(1-mu[k][i]), w.length*w[i]));
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < w.length; j++) {
                xkj[k][j] = (lambda*Math.pow(mu[k][j], w.length*w[j]))/
                            ((lambda-1)*Math.pow(mu[k][j], w.length*w[j]) + Math.pow(1+(lambda-1)*(1-mu[k][j]), w.length*w[j]));
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < w.length; i++) {
                yki[k][i] = (Math.pow(1+(lambda-1)*xki[k][i], a) - Math.pow(1-xki[k][i], a))/                                               
                            (Math.pow(1+(lambda-1)*xki[k][i], a) + (lambda-1)*Math.pow(1-xki[k][i], a));               
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < w.length; j++) {
                ykj[k][j] = (Math.pow(1+(lambda-1)*xkj[k][j], b) - Math.pow(1-xkj[k][j], b))/                                               
                            (Math.pow(1+(lambda-1)*xkj[k][j], b) + (lambda-1)*Math.pow(1-xkj[k][j], b));               
            }
        }              
        for (int k = 0; k < m; k++) {
            mu1[k] = 1.0;
            mu2[k] = 1.0;
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < w.length; i++) {
                for (int j = 0; j < w.length; j++) {
                    if (j != i) {
                        mu1[k] = mu1[k] * Math.pow((yki[k][i]+ykj[k][j]-yki[k][i]*ykj[k][j]-(1-lambda)*yki[k][i]*ykj[k][j])/
                                                  (1-(1-lambda)*yki[k][i]*ykj[k][j]), 1.0/(w.length*(w.length-1)));                        
                        mu2[k] = mu2[k] * Math.pow(1+(lambda-1)*(1-(yki[k][i]+ykj[k][j]-yki[k][i]*ykj[k][j]-(1-lambda)*yki[k][i]*ykj[k][j])/
                                                  (1-(1-lambda)*yki[k][i]*ykj[k][j])),1.0/(w.length*(w.length-1)));                       
                    }
                }
            }
            resultOfWFHAGBM[k] = (Math.pow((lambda*lambda-1)*mu1[k]+mu2[k], 1.0/(a+b)) - Math.pow(mu2[k]-mu1[k], 1.0/(a+b)))/
                                 (Math.pow((lambda*lambda-1)*mu1[k]+mu2[k], 1.0/(a+b)) + (lambda-1)*Math.pow(mu2[k]-mu1[k], 1.0/(a+b)));
        }
        return resultOfWFHAGBM;
    }
    
    //Define a function to aggregate each row of MN using the WFFAGBM operator
    public double[] WFFAGBM(int m, double[][] mu, double[] w, double a, double b, double epsilon) {
        double[] resultOfWFFAGBM = new double[m];
        double[][] xki = new double[m][w.length];
        double[][] xkj = new double[m][w.length];
        double[][] yki = new double[m][w.length];
        double[][] ykj = new double[m][w.length];       
        double[] mu1 = new double[m];
        double[] mu2 = new double[m];
        AMProcessSelection oOfLog = new AMProcessSelection();
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < w.length; i++) {
                xki[k][i] = oOfLog.LogAnyBase(epsilon, 1 + 
                            Math.pow(Math.pow(epsilon, mu[k][i])-1, w.length*w[i])/Math.pow(epsilon-1, w.length*w[i]-1));              
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < w.length; j++) {
                xkj[k][j] = oOfLog.LogAnyBase(epsilon, 1 + 
                            Math.pow(Math.pow(epsilon, mu[k][j])-1, w.length*w[j])/Math.pow(epsilon-1, w.length*w[j]-1));
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < w.length; i++) {
                yki[k][i] = 1 - oOfLog.LogAnyBase(epsilon, 1 + Math.pow(Math.pow(epsilon, 1-xki[k][i])-1, a)/Math.pow(epsilon-1, a-1)); 
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < w.length; j++) {
                ykj[k][j] = 1 - oOfLog.LogAnyBase(epsilon, 1 + Math.pow(Math.pow(epsilon, 1-xkj[k][j])-1, b)/Math.pow(epsilon-1, b-1));                
            }
        }              
        for (int k = 0; k < m; k++) {
            mu1[k] = 1.0;
            mu2[k] = 0.0;
        }       
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < w.length; i++) {
                for (int j = 0; j < w.length; j++) {
                    if (j != i) { 
                        mu1[k] = mu1[k] * Math.pow(Math.pow(epsilon, 1 - oOfLog.LogAnyBase(epsilon, 
                                 1 + Math.pow(Math.pow(epsilon, 1-xki[k][i])-1, a)*Math.pow(Math.pow(epsilon, 
                                 1 - xkj[k][j])-1, b)/Math.pow(epsilon-1, a+b-1)))-1, 1.0/(w.length*(w.length-1)));
                    }
                }
            }           
            mu2[k] = oOfLog.LogAnyBase(epsilon, 1+mu1[k]);
            resultOfWFFAGBM[k] = 1 - oOfLog.LogAnyBase(epsilon, 1 + Math.pow(Math.pow(epsilon, 1-mu2[k])-1, 
                                 1.0/(a+b))/Math.pow(epsilon-1, 1.0/(a+b)-1));
        }
        return resultOfWFFAGBM; 
    }
    
    //Compute the log value of any base
    public double LogAnyBase(double base, double value) {
        return Math.log(value)/Math.log(base);
    }
    
    //Define a function to sort the aggregation results
    public double[] SelectionSort(double[] domOfWFAGBM) {
        double[] tempArray = new double[domOfWFAGBM.length];
        for (int k=0; k<domOfWFAGBM.length; k++) {
            tempArray[k] = domOfWFAGBM[k];
        }     
        for (int i = 0; i < tempArray.length-1; i++) {
            int indexOfMax = i;
            for (int j = i+1; j < tempArray.length; j++) {
                if (tempArray[indexOfMax] < tempArray[j]) {
                    indexOfMax = j;
                }
            }
            if (indexOfMax != i) {
                double temp = tempArray[i];
                tempArray[i] = tempArray[indexOfMax];
                tempArray[indexOfMax] = temp;
            }
        }    
        return tempArray;
    }
}