/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amprocessselection;
import java.util.ArrayList;  
import java.util.List; 
import java.util.stream.*;
import java.util.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Yuchu Qin
 * @email: qinyuchu@hud.ac.uk
 * 
 */
public class AMProcessSelection {
    /**
     * @param args the command line arguments
     */
    //Assign values to the TFNs for quantifying the 9 linguistic values
    public interface C {
        public double ALPHAOfVVL = 0.0;
        public double ALPHAOfVL  = 0.0;
        public double ALPHAOfL   = 1.0/8.0;
        public double ALPHAOfSL  = 2.0/8.0;
        public double ALPHAOfM   = 3.0/8.0;
        public double ALPHAOfSH  = 4.0/8.0;
        public double ALPHAOfH   = 5.0/8.0;
        public double ALPHAOfVH  = 6.0/8.0;
        public double ALPHAOfVVH = 7.0/8.0;
    
        public double BETAOfVVL  = 0.0;
        public double BETAOfVL   = 1.0/8.0;
        public double BETAOfL    = 2.0/8.0;
        public double BETAOfSL   = 3.0/8.0;
        public double BETAOfM    = 4.0/8.0;
        public double BETAOfSH   = 5.0/8.0;
        public double BETAOfH    = 6.0/8.0;
        public double BETAOfVH   = 7.0/8.0;
        public double BETAOfVVH  = 1.0;

        public double GAMMAOfVVL = 1.0/8.0;
        public double GAMMAOfVL  = 2.0/8.0;
        public double GAMMAOfL   = 3.0/8.0;
        public double GAMMAOfSL  = 4.0/8.0;
        public double GAMMAOfM   = 5.0/8.0;
        public double GAMMAOfSH  = 6.0/8.0;
        public double GAMMAOfH   = 7.0/8.0;
        public double GAMMAOfVH  = 1.0;
        public double GAMMAOfVVH = 1.0;
    } 
    
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // TODO code application logic here
        AMProcessSelection amps = new AMProcessSelection();
        
        
        //Example 1
        //Assign values to columns 1, 2, 3, and 4 of the decision matrix M
        double[] column1 = {120.0, 150.0, 125.0, 185.0, 95.0, 600.0};
        double[] column2 = {6.5, 12.5, 21.0, 20.0, 3.5, 15.5};        
        double[] column3 = {65.0, 40.0, 30.0, 25.0, 30.0, 5.0};
        double[] column4 = {5.0, 8.5, 10.0, 10.0, 6.0, 1.0};
        
        //Compute the ratios of columns 1, 2, 3, and 4 of the fuzzy decision matrix MF
        double[] ratio1 = new double[column1.length];
        double[] ratio2 = new double[column2.length];
        double[] ratio3 = new double[column3.length];
        double[] ratio4 = new double[column4.length];
        ratio1 = amps.RatioOfNV(column1);
        ratio2 = amps.RatioOfNV(column2);
        ratio3 = amps.RatioOfNV(column3);
        ratio4 = amps.RatioOfNV(column4);
        System.out.println("Ratios of Column 1 are as follows:");
        for (int i = 0; i < column1.length; i++) {
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio1[i]));
        }
        System.out.println("Ratios of Column 2 are as follows:");
        for (int i = 0; i < column2.length; i++) {
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio2[i]));
        }
        System.out.println("Ratios of Column 3 are as follows:");
        for (int i = 0; i < column3.length; i++) {
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio3[i]));
        }
        System.out.println("Ratios of Column 4 are as follows:");
        for (int i = 0; i < column4.length; i++) {
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio4[i]));
        }
        
        //Compute the ratios of columns 5 and 6 of the fuzzy decision matrix MF           
        double[] alpha5 = {C.ALPHAOfVH, C.ALPHAOfVH, C.ALPHAOfH, C.ALPHAOfSH, C.ALPHAOfVH, C.ALPHAOfVVL};
        double[] beta5 = {C.BETAOfVH, C.BETAOfVH, C.BETAOfH, C.BETAOfSH, C.BETAOfVH, C.BETAOfVVL};
        double[] gamma5 = {C.GAMMAOfVH, C.GAMMAOfVH, C.GAMMAOfH, C.GAMMAOfSH, C.GAMMAOfVH, C.GAMMAOfVVL};    
        double[] alpha6 = {C.ALPHAOfM, C.ALPHAOfM, C.ALPHAOfVH, C.ALPHAOfSL, C.ALPHAOfSL, C.ALPHAOfVL};
        double[] beta6 = {C.BETAOfM, C.BETAOfM, C.BETAOfVH, C.BETAOfSL, C.BETAOfSL, C.BETAOfVL};
        double[] gamma6 = {C.GAMMAOfM, C.GAMMAOfM, C.GAMMAOfVH, C.GAMMAOfSL, C.GAMMAOfSL, C.GAMMAOfVL};
        double[] ratio5 = new double[alpha5.length];
        double[] ratio6 = new double[alpha6.length];
        ratio5 = amps.RatioOfLV(alpha5, beta5, gamma5);
        ratio6 = amps.RatioOfLV(alpha6, beta6, gamma6);
        System.out.println("Ratios of Column 5 are as follows:");
        for (int i = 0; i < alpha5.length; i++) {
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio5[i]));
        }
        System.out.println("Ratios of Column 6 are as follows:");
        for (int i = 0; i < alpha6.length; i++) {
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio6[i]));
        }
                               
        //Obtain the normalized fuzzy decision matrix MN      
        double[][][] MN = {
            {{1-ratio1[0], ratio1[0]}, {1-ratio2[0], ratio2[0]}, {ratio3[0], 1-ratio3[0]}, {ratio4[0], 1-ratio4[0]}, {1-ratio5[0], ratio5[0]}, {1-ratio6[0], ratio6[0]}},
            {{1-ratio1[1], ratio1[1]}, {1-ratio2[1], ratio2[1]}, {ratio3[1], 1-ratio3[1]}, {ratio4[1], 1-ratio4[1]}, {1-ratio5[1], ratio5[1]}, {1-ratio6[1], ratio6[1]}},
            {{1-ratio1[2], ratio1[2]}, {1-ratio2[2], ratio2[2]}, {ratio3[2], 1-ratio3[2]}, {ratio4[2], 1-ratio4[2]}, {1-ratio5[2], ratio5[2]}, {1-ratio6[2], ratio6[2]}},
            {{1-ratio1[3], ratio1[3]}, {1-ratio2[3], ratio2[3]}, {ratio3[3], 1-ratio3[3]}, {ratio4[3], 1-ratio4[3]}, {1-ratio5[3], ratio5[3]}, {1-ratio6[3], ratio6[3]}},
            {{1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {ratio3[4], 1-ratio3[4]}, {ratio4[4], 1-ratio4[4]}, {1-ratio5[4], ratio5[4]}, {1-ratio6[4], ratio6[4]}},
            {{1-ratio1[5], ratio1[5]}, {1-ratio2[5], ratio2[5]}, {ratio3[5], 1-ratio3[5]}, {ratio4[5], 1-ratio4[5]}, {1-ratio5[5], ratio5[5]}, {1-ratio6[5], ratio6[5]}}
        };                  
        double[] w = {0.1113, 0.1113, 0.0634, 0.0634, 0.3253, 0.3253};
        //double[] w = {0.3190, 0.3190, 0.1290, 0.1290, 0.0520, 0.0520};
              
        //double[] w = {0.40, 0.40, 0.05, 0.05, 0.05, 0.05};
        //double[] w = {0.05, 0.05, 0.40, 0.40, 0.05, 0.05};
        //double[] w = {0.05, 0.05, 0.05, 0.05, 0.40, 0.40};
        //double[] w = {0.20, 0.20, 0.20, 0.20, 0.10, 0.10};
        //double[] w = {0.20, 0.20, 0.10, 0.10, 0.20, 0.20};
        //double[] w = {0.10, 0.10, 0.20, 0.20, 0.20, 0.20};
             
        double q = 1.0;
        double a = 1.0;
        double b = 2.0; 
        int m = 6;
        int n = 6;
        double lambda = 10.0; 
        double epsilon = 10.0;
        double alpha = 0.5;
          
        double[] SUPP1221 = new double[m];
        double[] SUPP1331 = new double[m];
        double[] SUPP1441 = new double[m];
        double[] SUPP1551 = new double[m];
        double[] SUPP1661 = new double[m];
        double[] SUPP2332 = new double[m];
        double[] SUPP2442 = new double[m];
        double[] SUPP2552 = new double[m];
        double[] SUPP2662 = new double[m];
        double[] SUPP3443 = new double[m];
        double[] SUPP3553 = new double[m];
        double[] SUPP3663 = new double[m];
        double[] SUPP4554 = new double[m];
        double[] SUPP4664 = new double[m];
        double[] SUPP5665 = new double[m];
        
        for (int i = 0; i < m; i++) {          
            SUPP1221[i] = 1 - distanceValue(MN[i][0][0], MN[i][1][0]);
            SUPP1331[i] = 1 - distanceValue(MN[i][0][0], MN[i][2][0]);
            SUPP1441[i] = 1 - distanceValue(MN[i][0][0], MN[i][3][0]);
            SUPP1551[i] = 1 - distanceValue(MN[i][0][0], MN[i][4][0]);
            SUPP1661[i] = 1 - distanceValue(MN[i][0][0], MN[i][5][0]);
            SUPP2332[i] = 1 - distanceValue(MN[i][1][0], MN[i][2][0]);
            SUPP2442[i] = 1 - distanceValue(MN[i][1][0], MN[i][3][0]);
            SUPP2552[i] = 1 - distanceValue(MN[i][1][0], MN[i][4][0]);
            SUPP2662[i] = 1 - distanceValue(MN[i][1][0], MN[i][5][0]);
            SUPP3443[i] = 1 - distanceValue(MN[i][2][0], MN[i][3][0]);
            SUPP3553[i] = 1 - distanceValue(MN[i][2][0], MN[i][4][0]);
            SUPP3663[i] = 1 - distanceValue(MN[i][2][0], MN[i][5][0]);
            SUPP4554[i] = 1 - distanceValue(MN[i][3][0], MN[i][4][0]);
            SUPP4664[i] = 1 - distanceValue(MN[i][3][0], MN[i][5][0]);
            SUPP5665[i] = 1 - distanceValue(MN[i][4][0], MN[i][5][0]);                    
        }
        
        double[] TT1 = new double[m];
        double[] TT2 = new double[m]; 
        double[] TT3 = new double[m]; 
        double[] TT4 = new double[m];
        double[] TT5 = new double[m];
        double[] TT6 = new double[m];
        
        for (int i = 0; i < m; i++) {          
            TT1[i] = SUPP1221[i] + SUPP1331[i] + SUPP1441[i] + SUPP1551[i] + SUPP1661[i]; 
            TT2[i] = SUPP1221[i] + SUPP2332[i] + SUPP2442[i] + SUPP2552[i] + SUPP2662[i];
            TT3[i] = SUPP1331[i] + SUPP2332[i] + SUPP3443[i] + SUPP3553[i] + SUPP3663[i];
            TT4[i] = SUPP1441[i] + SUPP2442[i] + SUPP3443[i] + SUPP4554[i] + SUPP4664[i];
            TT5[i] = SUPP1551[i] + SUPP2552[i] + SUPP3553[i] + SUPP4554[i] + SUPP5665[i];
            TT6[i] = SUPP1661[i] + SUPP2662[i] + SUPP3663[i] + SUPP4664[i] + SUPP5665[i];
        }
                  
        double[] w1 = new double[m];
        double[] w2 = new double[m];
        double[] w3 = new double[m];
        double[] w4 = new double[m];
        double[] w5 = new double[m];
        double[] w6 = new double[m];
              
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        for (int i = 0; i < m; i++) {     
            w1[i] = (w[0]*(1.0 + TT1[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]) + w[5]*(1.0 + TT6[i]));
            w2[i] = (w[1]*(1.0 + TT2[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]) + w[5]*(1.0 + TT6[i]));
            w3[i] = (w[2]*(1.0 + TT3[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]) + w[5]*(1.0 + TT6[i]));
            w4[i] = (w[3]*(1.0 + TT4[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]) + w[5]*(1.0 + TT6[i]));
            w5[i] = (w[4]*(1.0 + TT5[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]) + w[5]*(1.0 + TT6[i]));
            w6[i] = (w[5]*(1.0 + TT6[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]) + w[5]*(1.0 + TT6[i]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(w6[i]));           
        }
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        
        double[][] ww = {
            {w1[0], w2[0], w3[0], w4[0], w5[0], w6[0]},
            {w1[1], w2[1], w3[1], w4[1], w5[1], w6[1]},
            {w1[2], w2[2], w3[2], w4[2], w5[2], w6[2]},
            {w1[3], w2[3], w3[3], w4[3], w5[3], w6[3]},
            {w1[4], w2[4], w3[4], w4[4], w5[4], w6[4]},
            {w1[5], w2[5], w3[5], w4[5], w5[5], w6[5]}
        };
        
        double[][] resultOfFAHWPBM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfFAHWPBM[k][r] = 0.0;
            }           
        }
        
        double[][] resultOfFAHWPGBM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfFAHWPGBM[k][r] = 0.0;
            }           
        }
        
        //resultOfFAHWPBM = amps.FAHWBM(lambda, m, n, q, MN, w, a, b);
        //resultOfFAHWPGBM = amps.FAHWGBM(lambda, m, n, q, MN, w, a, b);
        
        resultOfFAHWPBM = amps.FAHWPBM(lambda, m, n, q, MN, ww, a, b);
        resultOfFAHWPGBM = amps.FAHWPGBM(lambda, m, n, q, MN, ww, a, b);
        
        //resultOfFAHWPBM = amps.FAFWPBM(epsilon, m, n, q, MN, ww, a, b);
        //resultOfFAHWPGBM = amps.FAFWPGBM(epsilon, m, n, q, MN, ww, a, b);
        
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.print("BM[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(resultOfFAHWPBM[k][0]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(resultOfFAHWPBM[k][1]));
        }
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.print("GBM[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(resultOfFAHWPGBM[k][0]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(resultOfFAHWPGBM[k][1]));
        }
          
        double[] domOfAggOperator = new double[m];
        for (int k = 0; k < m; k++) {
            domOfAggOperator[k] = alpha*resultOfFAHWPBM[k][0] + (1.0-alpha)*resultOfFAHWPGBM[k][0];
        }
        
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.print("domOfAggOperator[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(domOfAggOperator[k]));
        } 
        /*
        File fileWrite1 = new File("CE1C1.txt");
        BufferedWriter writer1 = new BufferedWriter(new FileWriter(fileWrite1, true)); 
        File fileWrite2 = new File("CE1C2.txt");
        BufferedWriter writer2 = new BufferedWriter(new FileWriter(fileWrite2, true)); 
        File fileWrite3 = new File("CE1C3.txt");
        BufferedWriter writer3 = new BufferedWriter(new FileWriter(fileWrite3, true)); 
        File fileWrite4 = new File("CE1C4.txt");
        BufferedWriter writer4 = new BufferedWriter(new FileWriter(fileWrite4, true));
        File fileWrite5 = new File("CE1C5.txt");
        BufferedWriter writer5 = new BufferedWriter(new FileWriter(fileWrite5, true)); 
        File fileWrite6 = new File("CE1C6.txt");
        BufferedWriter writer6 = new BufferedWriter(new FileWriter(fileWrite6, true)); 
        
        writer1.write(String.valueOf(domOfAggOperator[0]) + "\r\n");
        writer2.write(String.valueOf(domOfAggOperator[1]) + "\r\n");
        writer3.write(String.valueOf(domOfAggOperator[2]) + "\r\n");
        writer4.write(String.valueOf(domOfAggOperator[3]) + "\r\n");
        writer5.write(String.valueOf(domOfAggOperator[4]) + "\r\n");
        writer6.write(String.valueOf(domOfAggOperator[5]) + "\r\n");
        writer1.close();
        writer2.close();
        writer3.close();
        writer4.close();
        writer5.close();
        writer6.close();
        
        
        int nX = 1000;              
        double[] rangeX = {1.0, 50.0};              
        double stepX = ( rangeX[1] - rangeX[0] ) / ( nX - 1);           
        double[] x = new double [nX];       
        double[] score = new double [nX];
        double[] SV = new double[m];         
        File fileWrite = new File("EXP4E1A6.txt");
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileWrite, true));       
        for (int ii = 0; ii < nX; ++ii) {            
            x[ii] = rangeX[0] + ii * stepX;               
            writer.write(String.valueOf(x[ii]) + " ");
            resultOfFAHWPBM = amps.FAHWPBM(x[ii], m, n, q, MN, ww, a, b);
            resultOfFAHWPGBM = amps.FAHWPGBM(x[ii], m, n, q, MN, ww, a, b);
            SV = amps.getScoreValue(m, alpha, resultOfFAHWPBM, resultOfFAHWPGBM);          
            score[ii] = SV[5];               
            writer.write(String.valueOf(score[ii]) + "\r\n");
        }             
        writer.close();
        
        
        
        int nX = 100;
        int nY = 100;
        
        double[] rangeX = {0.0, 10.0};
        double[] rangeY = {0.0, 10.0};
        
        double stepX = ( rangeX[1] - rangeX[0] ) / ( nX - 1);
        double stepY = ( rangeY[1] - rangeY[0] ) / ( nY - 1);
        
        double[][] x = new double [nX][nY];
        double[][] y = new double [nX][nY];
        double[][] score = new double [nX][nY];
        double[] scoreValueGBM = new double[m];
        double[] scoreValueBM = new double[m];
        
        File fileWrite = new File("COM.txt");
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileWrite, true));
        double alpha = 0.5;
        
        for (int i = 0; i < nX; ++i) {
            for (int j = 0; j < nY; ++j) {
                x[i][j] = rangeX[0] + i * stepX;
                //System.out.println("x[i][j]=" + x[i][j]);
                writer.write(String.valueOf(x[i][j]) + " ");
                y[i][j] = rangeY[0] + j * stepY;
                //System.out.println("y[i][j]=" + y[i][j]);
                writer.write(String.valueOf(y[i][j]) + " ");              
                scoreValueBM = amps.getDegreeOfMembership(m, amps.FAHWPBM(lambda, m, n, q, MN, ww, x[i][j], y[i][j]));
                scoreValueGBM = amps.getDegreeOfMembership(m, amps.FAHWPGBM(lambda, m, n, q, MN, ww, x[i][j], y[i][j]));
                score[i][j] = alpha*scoreValueBM[4] + (1.0-alpha)*scoreValueGBM[4];
                //System.out.println("score[i][j]=" + new java.text.DecimalFormat("#0.0000").format(score[i][j]));
                writer.write(String.valueOf(score[i][j]) + "\r\n");
            }
        }             
        writer.close();*/
                             
        //Sort the aggregation results of each row
        double[] tempArray = new double[m];
        tempArray = amps.SelectionSort(domOfAggOperator);
        
        //Output the rank
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                if (domOfAggOperator[j] == tempArray[i]) {
                    int index = j+1;
                    if (i == m-1) {
                        System.out.print("A[" + index + "]");
                    } else {
                        System.out.print("A[" + index + "] > ");
                    }
                }
            }
        }
        
        /*
        //Example 2
        double[] column1 = {1800.0, 600.0, 1430.0, 1703.0, 2000.0, 606.0};        
        double[] column2 = {53.0, 21.0, 50.0, 53.0, 60.0, 15.0};                            
        double[] column3 = {100.0, 95.0, 100.0, 100.0, 99.5, 100.0};    
        double[] column4 = {1.016, 0.300, 1.200, 0.762, 0.150, 0.600};
        double[] column5 = {6.0, 10.0, 10.0, 6.0, 10.0, 10.0};             
        //double[] column6 = {25.44, 41.47, 10.41, 5.03, 27.45, 41.47};
        //double[] column7 = {77.78, 1150.18, 315.03, 145.51, 679.15, 453.27};
        double[] column6 = {25.44, 41.47, 10.41, 5.03, 27.45, 41.47};
        double[] column7 = {77.78, 1150.18, 315.03, 145.51, 679.15, 453.27}; 
        
        
        double[] ratio1 = new double[column1.length];
        double[] ratio2 = new double[column2.length];
        double[] ratio3 = new double[column3.length];
        double[] ratio4 = new double[column4.length];
        double[] ratio5 = new double[column5.length];
        double[] ratio6 = new double[column6.length];
        double[] ratio7 = new double[column7.length];
        
        ratio1 = amps.RatioOfNV(column1);
        ratio2 = amps.RatioOfNV(column2);
        ratio3 = amps.RatioOfNV(column3);
        ratio4 = amps.RatioOfNV(column4);
        ratio5 = amps.RatioOfNV(column5);
        ratio6 = amps.RatioOfNV(column6);
        ratio7 = amps.RatioOfNV(column7);
        
        double[][][] MN = {
            {{ratio1[0], 1-ratio1[0]}, {ratio2[0], 1-ratio2[0]}, {1-ratio3[0], ratio3[0]}, {ratio4[0], 1-ratio4[0]}, {ratio5[0], 1-ratio5[0]}, {1-ratio6[0], ratio6[0]}, {1-ratio7[0], ratio7[0]}},
            {{ratio1[1], 1-ratio1[1]}, {ratio2[1], 1-ratio2[1]}, {1-ratio3[1], ratio3[1]}, {ratio4[1], 1-ratio4[1]}, {ratio5[1], 1-ratio5[1]}, {1-ratio6[1], ratio6[1]}, {1-ratio7[1], ratio7[1]}},
            {{ratio1[2], 1-ratio1[2]}, {ratio2[2], 1-ratio2[2]}, {1-ratio3[2], ratio3[2]}, {ratio4[2], 1-ratio4[2]}, {ratio5[2], 1-ratio5[2]}, {1-ratio6[2], ratio6[2]}, {1-ratio7[2], ratio7[2]}},
            {{ratio1[3], 1-ratio1[3]}, {ratio2[3], 1-ratio2[3]}, {1-ratio3[3], ratio3[3]}, {ratio4[3], 1-ratio4[3]}, {ratio5[3], 1-ratio5[3]}, {1-ratio6[3], ratio6[3]}, {1-ratio7[3], ratio7[3]}},
            {{ratio1[4], 1-ratio1[4]}, {ratio2[4], 1-ratio2[4]}, {1-ratio3[4], ratio3[4]}, {ratio4[4], 1-ratio4[4]}, {ratio5[4], 1-ratio5[4]}, {1-ratio6[4], ratio6[4]}, {1-ratio7[4], ratio7[4]}},
            {{ratio1[5], 1-ratio1[5]}, {ratio2[5], 1-ratio2[5]}, {1-ratio3[5], ratio3[5]}, {ratio4[5], 1-ratio4[5]}, {ratio5[5], 1-ratio5[5]}, {1-ratio6[5], ratio6[5]}, {1-ratio7[5], ratio7[5]}}
        };                  
        double[] w = {0.167, 0.144, 0.071, 0.024, 0.214, 0.190, 0.190};
      
        //double[] w = {0.40, 0.40, 0.04, 0.04, 0.04, 0.04, 0.04};
        //double[] w = {0.04, 0.04, 0.40, 0.04, 0.40, 0.04, 0.04};
        //double[] w = {0.04, 0.04, 0.04, 0.04, 0.04, 0.40, 0.40};
        //double[] w = {0.20, 0.20, 0.20, 0.10, 0.10, 0.10, 0.10};
        //double[] w = {0.10, 0.10, 0.20, 0.20, 0.20, 0.10, 0.10};
        //double[] w = {0.10, 0.10, 0.10, 0.10, 0.20, 0.20, 0.20};
        
        double q = 1.0;
        double a = 1.0;
        double b = 2.0; 
        int m = 6;
        int n = 7;
        double lambda = 10.0;        
        double alpha = 0.5;
          
        double[] SUPP1221 = new double[m];
        double[] SUPP1331 = new double[m];
        double[] SUPP1441 = new double[m];
        double[] SUPP1551 = new double[m];
        double[] SUPP1661 = new double[m];
        double[] SUPP1771 = new double[m];
        double[] SUPP2332 = new double[m];
        double[] SUPP2442 = new double[m];
        double[] SUPP2552 = new double[m];
        double[] SUPP2662 = new double[m];
        double[] SUPP2772 = new double[m];
        double[] SUPP3443 = new double[m];
        double[] SUPP3553 = new double[m];
        double[] SUPP3663 = new double[m];
        double[] SUPP3773 = new double[m];
        double[] SUPP4554 = new double[m];
        double[] SUPP4664 = new double[m];
        double[] SUPP4774 = new double[m];
        double[] SUPP5665 = new double[m];
        double[] SUPP5775 = new double[m];
        double[] SUPP6776 = new double[m];
        
        for (int i = 0; i < m; i++) {          
            SUPP1221[i] = 1 - distanceValue(MN[i][0][0], MN[i][1][0]);
            SUPP1331[i] = 1 - distanceValue(MN[i][0][0], MN[i][2][0]);
            SUPP1441[i] = 1 - distanceValue(MN[i][0][0], MN[i][3][0]);
            SUPP1551[i] = 1 - distanceValue(MN[i][0][0], MN[i][4][0]);
            SUPP1661[i] = 1 - distanceValue(MN[i][0][0], MN[i][5][0]);
            SUPP1771[i] = 1 - distanceValue(MN[i][0][0], MN[i][6][0]);
            SUPP2332[i] = 1 - distanceValue(MN[i][1][0], MN[i][2][0]);
            SUPP2442[i] = 1 - distanceValue(MN[i][1][0], MN[i][3][0]);
            SUPP2552[i] = 1 - distanceValue(MN[i][1][0], MN[i][4][0]);
            SUPP2662[i] = 1 - distanceValue(MN[i][1][0], MN[i][5][0]);
            SUPP2772[i] = 1 - distanceValue(MN[i][1][0], MN[i][6][0]);
            SUPP3443[i] = 1 - distanceValue(MN[i][2][0], MN[i][3][0]);
            SUPP3553[i] = 1 - distanceValue(MN[i][2][0], MN[i][4][0]);
            SUPP3663[i] = 1 - distanceValue(MN[i][2][0], MN[i][5][0]);
            SUPP3773[i] = 1 - distanceValue(MN[i][2][0], MN[i][6][0]);
            SUPP4554[i] = 1 - distanceValue(MN[i][3][0], MN[i][4][0]);
            SUPP4664[i] = 1 - distanceValue(MN[i][3][0], MN[i][5][0]);
            SUPP4774[i] = 1 - distanceValue(MN[i][3][0], MN[i][6][0]);
            SUPP5665[i] = 1 - distanceValue(MN[i][4][0], MN[i][5][0]);
            SUPP5775[i] = 1 - distanceValue(MN[i][4][0], MN[i][6][0]);
            SUPP6776[i] = 1 - distanceValue(MN[i][5][0], MN[i][6][0]);
        }
        
        double[] TT1 = new double[m];
        double[] TT2 = new double[m]; 
        double[] TT3 = new double[m]; 
        double[] TT4 = new double[m];
        double[] TT5 = new double[m];
        double[] TT6 = new double[m];
        double[] TT7 = new double[m];
        
        for (int i = 0; i < m; i++) {          
            TT1[i] = SUPP1221[i] + SUPP1331[i] + SUPP1441[i] + SUPP1551[i] + SUPP1661[i] + SUPP1771[i]; 
            TT2[i] = SUPP1221[i] + SUPP2332[i] + SUPP2442[i] + SUPP2552[i] + SUPP2662[i] + SUPP2772[i];
            TT3[i] = SUPP1331[i] + SUPP2332[i] + SUPP3443[i] + SUPP3553[i] + SUPP3663[i] + SUPP3773[i];
            TT4[i] = SUPP1441[i] + SUPP2442[i] + SUPP3443[i] + SUPP4554[i] + SUPP4664[i] + SUPP4774[i];
            TT5[i] = SUPP1551[i] + SUPP2552[i] + SUPP3553[i] + SUPP4554[i] + SUPP5665[i] + SUPP5775[i];
            TT6[i] = SUPP1661[i] + SUPP2662[i] + SUPP3663[i] + SUPP4664[i] + SUPP5665[i] + SUPP6776[i];
            TT7[i] = SUPP1771[i] + SUPP2772[i] + SUPP3773[i] + SUPP4774[i] + SUPP5775[i] + SUPP6776[i];
        }
                  
        double[] w1 = new double[m];
        double[] w2 = new double[m];
        double[] w3 = new double[m];
        double[] w4 = new double[m];
        double[] w5 = new double[m];
        double[] w6 = new double[m];
        double[] w7 = new double[m];
              
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        for (int i = 0; i < m; i++) {     
            w1[i] = (w[0]*(1.0 + TT1[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]) + w[5]*(1.0 + TT6[i]) + w[6]*(1.0 + TT7[i]));
            w2[i] = (w[1]*(1.0 + TT2[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]) + w[5]*(1.0 + TT6[i]) + w[6]*(1.0 + TT7[i]));
            w3[i] = (w[2]*(1.0 + TT3[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]) + w[5]*(1.0 + TT6[i]) + w[6]*(1.0 + TT7[i]));
            w4[i] = (w[3]*(1.0 + TT4[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]) + w[5]*(1.0 + TT6[i]) + w[6]*(1.0 + TT7[i]));
            w5[i] = (w[4]*(1.0 + TT5[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]) + w[5]*(1.0 + TT6[i]) + w[6]*(1.0 + TT7[i]));
            w6[i] = (w[5]*(1.0 + TT6[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]) + w[5]*(1.0 + TT6[i]) + w[6]*(1.0 + TT7[i]));
            w7[i] = (w[6]*(1.0 + TT7[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]) + w[5]*(1.0 + TT6[i]) + w[6]*(1.0 + TT7[i]));
            
            System.out.println(new java.text.DecimalFormat("#0.0000").format(w5[i]));           
        }
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        
        double[][] ww = {
            {w1[0], w2[0], w3[0], w4[0], w5[0], w6[0], w7[0]},
            {w1[1], w2[1], w3[1], w4[1], w5[1], w6[1], w7[1]},
            {w1[2], w2[2], w3[2], w4[2], w5[2], w6[2], w7[2]},
            {w1[3], w2[3], w3[3], w4[3], w5[3], w6[3], w7[3]},
            {w1[4], w2[4], w3[4], w4[4], w5[4], w6[4], w7[4]},
            {w1[5], w2[5], w3[5], w4[5], w5[5], w6[5], w7[5]}
        };
        
        double[][] resultOfFAHWPBM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfFAHWPBM[k][r] = 0.0;
            }           
        }
        
        double[][] resultOfFAHWPGBM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfFAHWPGBM[k][r] = 0.0;
            }           
        }
        
        //resultOfFAHWPBM = amps.FAHWPBM(lambda, m, n, q, MN, ww, a, b);
        //resultOfFAHWPGBM = amps.FAHWPGBM(lambda, m, n, q, MN, ww, a, b);
        
        resultOfFAHWPBM = amps.FAHWBM(lambda, m, n, q, MN, w, a, b);
        resultOfFAHWPGBM = amps.FAHWGBM(lambda, m, n, q, MN, w, a, b);
        
        //resultOfFAHWPBM = amps.FAFWPBM(10.0, m, n, q, MN, ww, a, b);
        //resultOfFAHWPGBM = amps.FAFWPGBM(10.0, m, n, q, MN, ww, a, b);
        
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.print("BM[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(resultOfFAHWPBM[k][0]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(resultOfFAHWPBM[k][1]));
        }
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.print("GBM[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(resultOfFAHWPGBM[k][0]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(resultOfFAHWPGBM[k][1]));
        }
          
        double[] domOfAggOperator = new double[m];
        for (int k = 0; k < m; k++) {
            domOfAggOperator[k] = alpha*resultOfFAHWPBM[k][0] + (1.0-alpha)*resultOfFAHWPGBM[k][0];
        }
        
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.print("domOfAggOperator[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(domOfAggOperator[k]));
        }
        
        int nX = 1000;              
        double[] rangeX = {1.0, 50.0};              
        double stepX = ( rangeX[1] - rangeX[0] ) / ( nX - 1);           
        double[] x = new double [nX];       
        double[] score = new double [nX];
        double[] SV = new double[m];         
        File fileWrite = new File("EXP4E2A6.txt");
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileWrite, true));       
        for (int ii = 0; ii < nX; ++ii) {            
            x[ii] = rangeX[0] + ii * stepX;               
            writer.write(String.valueOf(x[ii]) + " ");
            resultOfFAHWPBM = amps.FAHWPBM(x[ii], m, n, q, MN, ww, a, b);
            resultOfFAHWPGBM = amps.FAHWPGBM(x[ii], m, n, q, MN, ww, a, b);
            SV = amps.getScoreValue(m, alpha, resultOfFAHWPBM, resultOfFAHWPGBM);          
            score[ii] = SV[5];               
            writer.write(String.valueOf(score[ii]) + "\r\n");
        }             
        writer.close();
        
        //Sort the aggregation results of each row
        double[] tempArray = new double[m];
        tempArray = amps.SelectionSort(domOfAggOperator);
        
        //Output the rank
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                if (domOfAggOperator[j] == tempArray[i]) {
                    int index = j+1;
                    if (i == m-1) {
                        System.out.print("A[" + index + "]");
                    } else {
                        System.out.print("A[" + index + "] > ");
                    }
                }
            }
        }*/
                   
        /*
        //Example 3
        double[] column1 = {47.70, 35.08, 211.42, 146.14, 146.14, 481.78};        
        double[] column2 = {3.49, 7.80, 3.12, 19.03, 19.81, 24.96};                            
        //double[] column3 = {5.40, 2.32, 6.66, 3.40, 3.40, 9.02};
        
        double[] column3 = {5.40, 2.32, 6.66, 3.40, 3.40, 9.02};
        double[] column4 = {61.38, 55.10, 475.00, 47.22, 37.92, 936.60};
        double[] column5 = {1.20, 1.17, 7.80, 1.05, 1.32, 4.42};
       
        //double[] column1 = {231.34, 157.47, 1006.84, 413.75, 404.09, 1217.47};        
        //double[] column2 = {6.44, 10.62, 4.25, 21.13, 21.26, 26.53};                            
        //double[] column3 = {20.48, 13.64, 37.52, 7.76, 7.33, 23.79};    
        //double[] column4 = {61.38, 50.84, 475.00, 47.22, 39.24, 936.60};
        //double[] column5 = {1.20, 1.17, 7.80, 1.05, 1.32, 4.42};
        
        double[] ratio1 = new double[column1.length];
        double[] ratio2 = new double[column2.length];
        double[] ratio3 = new double[column3.length];
        double[] ratio4 = new double[column4.length];
        double[] ratio5 = new double[column5.length]; 
                
        ratio1 = amps.RatioOfNV(column1);
        ratio2 = amps.RatioOfNV(column2);
        ratio3 = amps.RatioOfNV(column3);
        ratio4 = amps.RatioOfNV(column4);
        ratio5 = amps.RatioOfNV(column5);     
        
        double[][][] MN = {
            {{1-ratio1[0], ratio1[0]}, {1-ratio2[0], ratio2[0]}, {1-ratio3[0], ratio3[0]}, {ratio4[0], 1-ratio4[0]}, {1-ratio5[0], ratio5[0]}},
            {{1-ratio1[1], ratio1[1]}, {1-ratio2[1], ratio2[1]}, {1-ratio3[1], ratio3[1]}, {ratio4[1], 1-ratio4[1]}, {1-ratio5[1], ratio5[1]}},
            {{1-ratio1[2], ratio1[2]}, {1-ratio2[2], ratio2[2]}, {1-ratio3[2], ratio3[2]}, {ratio4[2], 1-ratio4[2]}, {1-ratio5[2], ratio5[2]}},
            {{1-ratio1[3], ratio1[3]}, {1-ratio2[3], ratio2[3]}, {1-ratio3[3], ratio3[3]}, {ratio4[3], 1-ratio4[3]}, {1-ratio5[3], ratio5[3]}},
            {{1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {ratio4[4], 1-ratio4[4]}, {1-ratio5[4], ratio5[4]}},
            {{1-ratio1[5], ratio1[5]}, {1-ratio2[5], ratio2[5]}, {1-ratio3[5], ratio3[5]}, {ratio4[5], 1-ratio4[5]}, {1-ratio5[5], ratio5[5]}}
        };                  
        double[] w = {0.15, 0.15, 0.5, 0.1, 0.1};    
              
        //double[] w = {0.6, 0.1, 0.1, 0.1, 0.1};
        //double[] w = {0.1, 0.1, 0.6, 0.1, 0.1};
        //double[] w = {0.1, 0.1, 0.1, 0.1, 0.6};
        //double[] w = {0.3, 0.3, 0.2, 0.1, 0.1};
        //double[] w = {0.1, 0.3, 0.2, 0.3, 0.1};
        //double[] w = {0.1, 0.1, 0.2, 0.3, 0.3};
        
        double q = 1.0;
        double a = 1.0;
        double b = 2.0; 
        int m = 6;
        int n = 5;
        double lambda = 10.0;        
        double alpha = 0.5;
          
        double[] SUPP1221 = new double[m];
        double[] SUPP1331 = new double[m];
        double[] SUPP1441 = new double[m];
        double[] SUPP1551 = new double[m];
        
        double[] SUPP2332 = new double[m];
        double[] SUPP2442 = new double[m];
        double[] SUPP2552 = new double[m];
        
        double[] SUPP3443 = new double[m];
        double[] SUPP3553 = new double[m];
        
        double[] SUPP4554 = new double[m];
        
        
        for (int i = 0; i < m; i++) {          
            SUPP1221[i] = 1 - distanceValue(MN[i][0][0], MN[i][1][0]);
            SUPP1331[i] = 1 - distanceValue(MN[i][0][0], MN[i][2][0]);
            SUPP1441[i] = 1 - distanceValue(MN[i][0][0], MN[i][3][0]);
            SUPP1551[i] = 1 - distanceValue(MN[i][0][0], MN[i][4][0]);
           
            SUPP2332[i] = 1 - distanceValue(MN[i][1][0], MN[i][2][0]);
            SUPP2442[i] = 1 - distanceValue(MN[i][1][0], MN[i][3][0]);
            SUPP2552[i] = 1 - distanceValue(MN[i][1][0], MN[i][4][0]);
           
            SUPP3443[i] = 1 - distanceValue(MN[i][2][0], MN[i][3][0]);
            SUPP3553[i] = 1 - distanceValue(MN[i][2][0], MN[i][4][0]);
            
            SUPP4554[i] = 1 - distanceValue(MN[i][3][0], MN[i][4][0]);
            
        }
        
        double[] TT1 = new double[m];
        double[] TT2 = new double[m]; 
        double[] TT3 = new double[m]; 
        double[] TT4 = new double[m];
        double[] TT5 = new double[m];      
        
        for (int i = 0; i < m; i++) {          
            TT1[i] = SUPP1221[i] + SUPP1331[i] + SUPP1441[i] + SUPP1551[i]; 
            TT2[i] = SUPP1221[i] + SUPP2332[i] + SUPP2442[i] + SUPP2552[i];
            TT3[i] = SUPP1331[i] + SUPP2332[i] + SUPP3443[i] + SUPP3553[i];
            TT4[i] = SUPP1441[i] + SUPP2442[i] + SUPP3443[i] + SUPP4554[i];
            TT5[i] = SUPP1551[i] + SUPP2552[i] + SUPP3553[i] + SUPP4554[i];
            
        }
                  
        double[] w1 = new double[m];
        double[] w2 = new double[m];
        double[] w3 = new double[m];
        double[] w4 = new double[m];
        double[] w5 = new double[m];
       
              
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        for (int i = 0; i < m; i++) {     
            w1[i] = (w[0]*(1.0 + TT1[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
            w2[i] = (w[1]*(1.0 + TT2[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
            w3[i] = (w[2]*(1.0 + TT3[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
            w4[i] = (w[3]*(1.0 + TT4[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
            w5[i] = (w[4]*(1.0 + TT5[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
           
            System.out.println(new java.text.DecimalFormat("#0.0000").format(w5[i]));           
        }
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        
        double[][] ww = {
            {w1[0], w2[0], w3[0], w4[0], w5[0]},
            {w1[1], w2[1], w3[1], w4[1], w5[1]},
            {w1[2], w2[2], w3[2], w4[2], w5[2]},
            {w1[3], w2[3], w3[3], w4[3], w5[3]},
            {w1[4], w2[4], w3[4], w4[4], w5[4]},
            {w1[5], w2[5], w3[5], w4[5], w5[5]}
        };
        
        double[][] resultOfFAHWPBM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfFAHWPBM[k][r] = 0.0;
            }           
        }
        
        double[][] resultOfFAHWPGBM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfFAHWPGBM[k][r] = 0.0;
            }           
        }
        
        resultOfFAHWPBM = amps.FAHWPBM(lambda, m, n, q, MN, ww, a, b);
        resultOfFAHWPGBM = amps.FAHWPGBM(lambda, m, n, q, MN, ww, a, b);
        
        //resultOfFAHWPBM = amps.FAHWBM(lambda, m, n, q, MN, w, a, b);
        //resultOfFAHWPGBM = amps.FAHWGBM(lambda, m, n, q, MN, w, a, b);
        
        //resultOfFAHWPBM = amps.FAFWPBM(10.0, m, n, q, MN, ww, a, b);
        //resultOfFAHWPGBM = amps.FAFWPGBM(10.0, m, n, q, MN, ww, a, b);
        
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.print("BM[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(resultOfFAHWPBM[k][0]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(resultOfFAHWPBM[k][1]));
        }
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.print("GBM[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(resultOfFAHWPGBM[k][0]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(resultOfFAHWPGBM[k][1]));
        }
          
        double[] domOfAggOperator = new double[m];
        for (int k = 0; k < m; k++) {
            domOfAggOperator[k] = alpha*resultOfFAHWPBM[k][0] + (1.0-alpha)*resultOfFAHWPGBM[k][0];
        }
        
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.print("domOfAggOperator[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(domOfAggOperator[k]));
        }
        
        File fileWrite1 = new File("CCP1.txt");
        BufferedWriter writer1 = new BufferedWriter(new FileWriter(fileWrite1, true)); 
        File fileWrite2 = new File("CCP2.txt");
        BufferedWriter writer2 = new BufferedWriter(new FileWriter(fileWrite2, true)); 
        File fileWrite3 = new File("CCP3.txt");
        BufferedWriter writer3 = new BufferedWriter(new FileWriter(fileWrite3, true)); 
        File fileWrite4 = new File("CCP4.txt");
        BufferedWriter writer4 = new BufferedWriter(new FileWriter(fileWrite4, true));
        File fileWrite5 = new File("CCP5.txt");
        BufferedWriter writer5 = new BufferedWriter(new FileWriter(fileWrite5, true)); 
        File fileWrite6 = new File("CCP6.txt");
        BufferedWriter writer6 = new BufferedWriter(new FileWriter(fileWrite6, true)); 
        
        writer1.write(String.valueOf(domOfAggOperator[0]) + "\r\n");
        writer2.write(String.valueOf(domOfAggOperator[1]) + "\r\n");
        writer3.write(String.valueOf(domOfAggOperator[2]) + "\r\n");
        writer4.write(String.valueOf(domOfAggOperator[3]) + "\r\n");
        writer5.write(String.valueOf(domOfAggOperator[4]) + "\r\n");
        writer6.write(String.valueOf(domOfAggOperator[5]) + "\r\n");
        writer1.close();
        writer2.close();
        writer3.close();
        writer4.close();
        writer5.close();
        writer6.close();
        
        
        int nX = 1000;              
        double[] rangeX = {1.0, 50.0};              
        double stepX = ( rangeX[1] - rangeX[0] ) / ( nX - 1);           
        double[] x = new double [nX];       
        double[] score = new double [nX];
        double[] SV = new double[m];         
        File fileWrite = new File("EXP4E3A6.txt");
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileWrite, true));       
        for (int ii = 0; ii < nX; ++ii) {            
            x[ii] = rangeX[0] + ii * stepX;               
            writer.write(String.valueOf(x[ii]) + " ");
            resultOfFAHWPBM = amps.FAHWPBM(x[ii], m, n, q, MN, ww, a, b);
            resultOfFAHWPGBM = amps.FAHWPGBM(x[ii], m, n, q, MN, ww, a, b);
            SV = amps.getScoreValue(m, alpha, resultOfFAHWPBM, resultOfFAHWPGBM);          
            score[ii] = SV[5];               
            writer.write(String.valueOf(score[ii]) + "\r\n");
        }             
        writer.close();
        
        //Sort the aggregation results of each row
        double[] tempArray = new double[m];
        tempArray = amps.SelectionSort(domOfAggOperator);
        
        //Output the rank
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                if (domOfAggOperator[j] == tempArray[i]) {
                    int index = j+1;
                    if (i == m-1) {
                        System.out.print("A[" + index + "]");
                    } else {
                        System.out.print("A[" + index + "] > ");
                    }
                }
            }
        }*/
        
        /*
        //Example 4
        //double[] column1 = {24923.0, 15314.0, 4140.0, 11081.0, 3418.0, 32379.0};  
        
        double[] column1 = {24923.0, 15314.0, 4140.0, 11081.0, 3418.0, 32379.0};  
        double[] column2 = {3807.0, 1531.0, 353.0, 2757.0, 623.0, 9501.0};                            
        double[] column3 = {0.21, 0.21, 0.20, 1.56, 1.56, 1.66};    
                          
        double[] ratio1 = new double[column1.length];
        double[] ratio2 = new double[column2.length];
        double[] ratio3 = new double[column3.length];      
                
        ratio1 = amps.RatioOfNV(column1);
        ratio2 = amps.RatioOfNV(column2);
        ratio3 = amps.RatioOfNV(column3);       
        
        double[][][] MN = {
            {{1-ratio1[0], ratio1[0]}, {1-ratio2[0], ratio2[0]}, {1-ratio3[0], ratio3[0]}},
            {{1-ratio1[1], ratio1[1]}, {1-ratio2[1], ratio2[1]}, {1-ratio3[1], ratio3[1]}},
            {{1-ratio1[2], ratio1[2]}, {1-ratio2[2], ratio2[2]}, {1-ratio3[2], ratio3[2]}},
            {{1-ratio1[3], ratio1[3]}, {1-ratio2[3], ratio2[3]}, {1-ratio3[3], ratio3[3]}},
            {{1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}},
            {{1-ratio1[5], ratio1[5]}, {1-ratio2[5], ratio2[5]}, {1-ratio3[5], ratio3[5]}}
        };                  
        double[] w = {0.6700, 0.2475, 0.0825};
        
        //double[] w = {0.80, 0.10, 0.10};
        //double[] w = {0.10, 0.80, 0.10};
        //double[] w = {0.10, 0.10, 0.80};
        //double[] w = {0.45, 0.45, 0.10};
        //double[] w = {0.45, 0.10, 0.45};
        //double[] w = {0.10, 0.45, 0.45};
        
        double q = 1.0;
        double a = 1.0;
        double b = 2.0; 
        int m = 6;
        int n = 3;
        double lambda = 10.0;        
        double alpha = 0.5;
          
        double[] SUPP1221 = new double[m];
        double[] SUPP1331 = new double[m];            
        double[] SUPP2332 = new double[m];
                     
        for (int i = 0; i < m; i++) {          
            SUPP1221[i] = 1 - distanceValue(MN[i][0][0], MN[i][1][0]);
            SUPP1331[i] = 1 - distanceValue(MN[i][0][0], MN[i][2][0]);                   
            SUPP2332[i] = 1 - distanceValue(MN[i][1][0], MN[i][2][0]);          
        }
        
        double[] TT1 = new double[m];
        double[] TT2 = new double[m]; 
        double[] TT3 = new double[m];        
              
        for (int i = 0; i < m; i++) {          
            TT1[i] = SUPP1221[i] + SUPP1331[i]; 
            TT2[i] = SUPP1221[i] + SUPP2332[i];
            TT3[i] = SUPP1331[i] + SUPP2332[i];           
        }
                  
        double[] w1 = new double[m];
        double[] w2 = new double[m];
        double[] w3 = new double[m];
                           
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        for (int i = 0; i < m; i++) {     
            w1[i] = (w[0]*(1.0 + TT1[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]));
            w2[i] = (w[1]*(1.0 + TT2[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]));
            w3[i] = (w[2]*(1.0 + TT3[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]));            
            System.out.println(new java.text.DecimalFormat("#0.0000").format(w1[i]));           
        }
        System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        
        double[][] ww = {
            {w1[0], w2[0], w3[0]},
            {w1[1], w2[1], w3[1]},
            {w1[2], w2[2], w3[2]},
            {w1[3], w2[3], w3[3]},
            {w1[4], w2[4], w3[4]},
            {w1[5], w2[5], w3[5]}
        };
        
        double[][] resultOfFAHWPBM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfFAHWPBM[k][r] = 0.0;
            }           
        }
        
        double[][] resultOfFAHWPGBM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfFAHWPGBM[k][r] = 0.0;
            }           
        }
        
        //resultOfFAHWPBM = amps.FAHWPBM(lambda, m, n, q, MN, ww, a, b);
        //resultOfFAHWPGBM = amps.FAHWPGBM(lambda, m, n, q, MN, ww, a, b);
        
        resultOfFAHWPBM = amps.FAHWBM(lambda, m, n, q, MN, w, a, b);
        resultOfFAHWPGBM = amps.FAHWGBM(lambda, m, n, q, MN, w, a, b);
        
        //resultOfFAHWPBM = amps.FAFWPBM(10.0, m, n, q, MN, ww, a, b);
        //resultOfFAHWPGBM = amps.FAFWPGBM(10.0, m, n, q, MN, ww, a, b);
        
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.print("BM[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(resultOfFAHWPBM[k][0]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(resultOfFAHWPBM[k][1]));
        }
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.print("GBM[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(resultOfFAHWPGBM[k][0]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(resultOfFAHWPGBM[k][1]));
        }
          
        double[] domOfAggOperator = new double[m];
        for (int k = 0; k < m; k++) {
            domOfAggOperator[k] = alpha*resultOfFAHWPBM[k][0] + (1.0-alpha)*resultOfFAHWPGBM[k][0];
        }
        
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.print("domOfAggOperator[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(domOfAggOperator[k]));
        }
        
        int nX = 1000;              
        double[] rangeX = {1.0, 50.0};              
        double stepX = ( rangeX[1] - rangeX[0] ) / ( nX - 1);           
        double[] x = new double [nX];       
        double[] score = new double [nX];
        double[] SV = new double[m];         
        File fileWrite = new File("EXP4E4A6.txt");
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileWrite, true));       
        for (int ii = 0; ii < nX; ++ii) {            
            x[ii] = rangeX[0] + ii * stepX;               
            writer.write(String.valueOf(x[ii]) + " ");
            resultOfFAHWPBM = amps.FAHWPBM(x[ii], m, n, q, MN, ww, a, b);
            resultOfFAHWPGBM = amps.FAHWPGBM(x[ii], m, n, q, MN, ww, a, b);
            SV = amps.getScoreValue(m, alpha, resultOfFAHWPBM, resultOfFAHWPGBM);          
            score[ii] = SV[5];               
            writer.write(String.valueOf(score[ii]) + "\r\n");
        }             
        writer.close();
        
        File fileWrite1 = new File("CE4C1.txt");
        BufferedWriter writer1 = new BufferedWriter(new FileWriter(fileWrite1, true)); 
        File fileWrite2 = new File("CE4C2.txt");
        BufferedWriter writer2 = new BufferedWriter(new FileWriter(fileWrite2, true)); 
        File fileWrite3 = new File("CE4C3.txt");
        BufferedWriter writer3 = new BufferedWriter(new FileWriter(fileWrite3, true)); 
        File fileWrite4 = new File("CE4C4.txt");
        BufferedWriter writer4 = new BufferedWriter(new FileWriter(fileWrite4, true));
        File fileWrite5 = new File("CE4C5.txt");
        BufferedWriter writer5 = new BufferedWriter(new FileWriter(fileWrite5, true)); 
        File fileWrite6 = new File("CE4C6.txt");
        BufferedWriter writer6 = new BufferedWriter(new FileWriter(fileWrite6, true)); 
        
        writer1.write(String.valueOf(domOfAggOperator[0]) + "\r\n");
        writer2.write(String.valueOf(domOfAggOperator[1]) + "\r\n");
        writer3.write(String.valueOf(domOfAggOperator[2]) + "\r\n");
        writer4.write(String.valueOf(domOfAggOperator[3]) + "\r\n");
        writer5.write(String.valueOf(domOfAggOperator[4]) + "\r\n");
        writer6.write(String.valueOf(domOfAggOperator[5]) + "\r\n");
        writer1.close();
        writer2.close();
        writer3.close();
        writer4.close();
        writer5.close();
        writer6.close();
        
        //Sort the aggregation results of each row
        double[] tempArray = new double[m];
        tempArray = amps.SelectionSort(domOfAggOperator);
        
        //Output the rank
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < m; j++) {
                if (domOfAggOperator[j] == tempArray[i]) {
                    int index = j+1;
                    if (i == m-1) {
                        System.out.print("A[" + index + "]");
                    } else {
                        System.out.print("A[" + index + "] > ");
                    }
                }
            }
        }*/                              
    }

    //Define a function to quantify numerical values
    public double[] RatioOfNV(double[] column) {
        double[] ratio = new double[column.length];
        double quadraticSum = 0.0;
        for (int i = 0; i < column.length; i++) {
            quadraticSum = quadraticSum + column[i]*column[i];
        }
        
        for (int j = 0; j < column.length; j++) {
            ratio[j] = column[j]/(Math.pow(quadraticSum, 0.5));
        }       
        return ratio;
    }
    
    //Define a function to quantify linguistic values
    public double[] RatioOfLV(double[] alpha, double[] beta, double[] gamma) {
        double[] ratio = new double[alpha.length];
        double quadraticSumOfGamma = 0.0;
         for (int i = 0; i < gamma.length; i++) {
            quadraticSumOfGamma = quadraticSumOfGamma + gamma[i]*gamma[i];
        }
        for (int j = 0; j < alpha.length; j++) {
            ratio[j] = (1.0/3.0) * ((alpha[j]/(Math.pow(quadraticSumOfGamma, 0.5))) + 
                                    (beta[j]/(Math.pow(quadraticSumOfGamma, 0.5))) + 
                                    (gamma[j]/(Math.pow(quadraticSumOfGamma, 0.5))));                              
        }       
        return ratio;
    }
    
    public double[][] FAHWPBM(double delta, int m, int n, double q, double[][][] theta, double[][] w, double s, double t) {
        double[][] resultOfqROFWHABM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWHABM[k][r] = 0.0;
            }           
        }
        double[][] xki = new double[m][n];
        double[][] xkj = new double[m][n];
        double[][] yki = new double[m][n];
        double[][] ykj = new double[m][n];
        double[] a1 = new double[m];
        double[] a2 = new double[m];
        double[] b1 = new double[m];
        double[] b2 = new double[m];
        double[] mu1 = new double[m];
        double[] mu2 = new double[m];
        double[] nu1 = new double[m];
        double[] nu2 = new double[m];
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                xki[k][i] = (delta*Math.pow((Math.pow(1+(delta-1)*Math.pow(theta[k][i][0],q), n*w[k][i]) - 
                                   Math.pow(1-Math.pow(theta[k][i][0],q), n*w[k][i])) /
                                  (Math.pow(1+(delta-1)*Math.pow(theta[k][i][0],q), n*w[k][i]) + 
                            (delta-1)*Math.pow(1-Math.pow(theta[k][i][0],q), n*w[k][i])), s)) / 
                          (((delta-1)*Math.pow((Math.pow(1+(delta-1)*Math.pow(theta[k][i][0],q), n*w[k][i]) - 
                                      Math.pow(1-Math.pow(theta[k][i][0],q), n*w[k][i])) /
                                     (Math.pow(1+(delta-1)*Math.pow(theta[k][i][0],q), n*w[k][i]) + 
                            (delta-1)*Math.pow(1-Math.pow(theta[k][i][0],q), n*w[k][i])), s)) +                      
                                      Math.pow(delta-(delta-1)*((Math.pow(1+(delta-1)*Math.pow(theta[k][i][0],q), n*w[k][i]) - 
                                      Math.pow(1-Math.pow(theta[k][i][0],q), n*w[k][i])) /                                         
                                     (Math.pow(1+(delta-1)*Math.pow(theta[k][i][0],q), n*w[k][i]) + 
                            (delta-1)*Math.pow(1-Math.pow(theta[k][i][0],q), n*w[k][i]))), s));                       
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                 xkj[k][j] = (delta*Math.pow((Math.pow(1+(delta-1)*Math.pow(theta[k][j][0],q), n*w[k][j]) - 
                                    Math.pow(1-Math.pow(theta[k][j][0],q), n*w[k][j])) /
                                   (Math.pow(1+(delta-1)*Math.pow(theta[k][j][0],q), n*w[k][j]) + 
                             (delta-1)*Math.pow(1-Math.pow(theta[k][j][0],q), n*w[k][j])), t)) / 
                           (((delta-1)*Math.pow((Math.pow(1+(delta-1)*Math.pow(theta[k][j][0],q), n*w[k][j]) - 
                                       Math.pow(1-Math.pow(theta[k][j][0],q), n*w[k][j])) /
                                      (Math.pow(1+(delta-1)*Math.pow(theta[k][j][0],q), n*w[k][j]) + 
                             (delta-1)*Math.pow(1-Math.pow(theta[k][j][0],q), n*w[k][j])), t)) +                      
                                       Math.pow(delta-(delta-1)*((Math.pow(1+(delta-1)*Math.pow(theta[k][j][0],q), n*w[k][j]) - 
                                       Math.pow(1-Math.pow(theta[k][j][0],q), n*w[k][j])) /                                         
                                      (Math.pow(1+(delta-1)*Math.pow(theta[k][j][0],q), n*w[k][j]) + 
                             (delta-1)*Math.pow(1-Math.pow(theta[k][j][0],q), n*w[k][j]))), t));                       
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                yki[k][i] = (Math.pow((1 + (delta-1)*((delta*Math.pow(theta[k][i][1],n*w[k][i]))/
                            ((delta-1)*Math.pow(theta[k][i][1],q*n*w[k][i]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][i][1], q)), n*w[k][i])))), s) - 
                             Math.pow(1-((delta*Math.pow(theta[k][i][1],n*w[k][i]))/((delta-1)*
                             Math.pow(theta[k][i][1],q*n*w[k][i]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][i][1], q)), n*w[k][i]))), s)) /
                            (Math.pow((1 + ((delta-1)*((delta*Math.pow(theta[k][i][1],n*w[k][i]))/
                            ((delta-1)*Math.pow(theta[k][i][1],q*n*w[k][i]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][i][1], q)), n*w[k][i]))))), s) + 
                            (delta-1)*Math.pow(1-(delta*Math.pow(theta[k][i][1],n*w[k][i]))/(((delta-1)*
                             Math.pow(theta[k][i][1],q*n*w[k][i]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][i][1], q)), n*w[k][i]))), s));               
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                ykj[k][j] = (Math.pow((1 + (delta-1)*((delta*Math.pow(theta[k][j][1],n*w[k][j]))/
                            ((delta-1)*Math.pow(theta[k][j][1],q*n*w[k][j]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][j][1], q)), n*w[k][j])))), t) - 
                             Math.pow(1-((delta*Math.pow(theta[k][j][1],n*w[k][j]))/((delta-1)*
                             Math.pow(theta[k][j][1],q*n*w[k][j]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][j][1], q)), n*w[k][j]))), t)) /
                            (Math.pow((1 + ((delta-1)*((delta*Math.pow(theta[k][j][1],n*w[k][j]))/
                            ((delta-1)*Math.pow(theta[k][j][1],q*n*w[k][j]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][j][1], q)), n*w[k][j]))))), t) + 
                            (delta-1)*Math.pow(1-(delta*Math.pow(theta[k][j][1],n*w[k][j]))/(((delta-1)*
                             Math.pow(theta[k][j][1],q*n*w[k][j]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][j][1], q)), n*w[k][j]))), t));               
            }
        }
        for (int k = 0; k < m; k++) {
            a1[k] = 1.0;
            a2[k] = 1.0;
            b1[k] = 1.0;
            b2[k] = 1.0;
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (j != i) {
                        a1[k] = a1[k] * (1 + (delta-1)*((xki[k][i]*xkj[k][j])/(delta+(1-delta)*(xki[k][i]+xkj[k][j]-xki[k][i]*xkj[k][j]))));
                        a2[k] = a2[k] * (1 - ((xki[k][i]*xkj[k][j])/(delta+(1-delta)*(xki[k][i]+xkj[k][j]-xki[k][i]*xkj[k][j]))));
                        b1[k] = b1[k] * ((yki[k][i]+ykj[k][j]+(delta-2)*yki[k][i]*ykj[k][j])/(1-(1-delta)*yki[k][i]*ykj[k][j]));
                        b2[k] = b2[k] * (delta-(delta-1)*((yki[k][i]+ykj[k][j]+(delta-2)*yki[k][i]*ykj[k][j])/(1-(1-delta)*yki[k][i]*ykj[k][j])));
                    }
                }
            }
            mu1[k] = Math.pow(1 + (delta-1)*((a1[k]-a2[k])/(a1[k]+(delta-1)*a2[k])), 1.0/(n*(n-1)));
            mu2[k] = Math.pow(1 - (a1[k]-a2[k])/(a1[k]+(delta-1)*a2[k]), 1.0/(n*(n-1)));
            nu1[k] = Math.pow((delta*b1[k])/((delta-1)*b1[k]+b2[k]), 1.0/(n*(n-1)));
            nu2[k] = Math.pow(delta - (delta-1)*((delta*b1[k])/((delta-1)*b1[k]+b2[k])), 1.0/(n*(n-1)));           
            resultOfqROFWHABM[k][0] = Math.pow((delta*Math.pow((mu1[k]-mu2[k])/(mu1[k]+(delta-1)*mu2[k]), 1.0/(s+t)))/
                                     ((delta-1)*Math.pow((mu1[k]-mu2[k])/(mu1[k]+(delta-1)*mu2[k]), 1.0/(s+t))+
                                      Math.pow(delta-(delta-1)*((mu1[k]-mu2[k])/(mu1[k]+(delta-1)*mu2[k])), 1.0/(s+t))), 1.0/q);
            resultOfqROFWHABM[k][1] = Math.pow((Math.pow(1 + (delta-1)*((delta*nu1[k])/((delta-1)*nu1[k]+nu2[k])), 1.0/(s+t)) - 
                                      Math.pow(1 - (delta*nu1[k])/((delta-1)*nu1[k]+nu2[k]), 1.0/(s+t)))/
                                     (Math.pow(1 + (delta-1)*((delta*nu1[k])/((delta-1)*nu1[k]+nu2[k])), 1.0/(s+t)) + 
                                     (delta-1)*Math.pow(1 - (delta*nu1[k])/((delta-1)*nu1[k]+nu2[k]), 1.0/(s+t))), 1.0/q);
        }
        return resultOfqROFWHABM;
    }
    
    public double[][] FAHWPGBM(double lambda, int m, int n, double q, double[][][] theta, double[][] w, double a, double b) {
        double[][] resultOfqROFWHAGBM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWHAGBM[k][r] = 0.0;
            }           
        }
        double[][] xki = new double[m][n];
        double[][] xkj = new double[m][n];
        double[][] yki = new double[m][n];
        double[][] ykj = new double[m][n];
        double[][] x1ki = new double[m][n];
        double[][] x1kj = new double[m][n];
        double[][] y1ki = new double[m][n];
        double[][] y1kj = new double[m][n];
        double[] mu1 = new double[m];
        double[] mu2 = new double[m];
        double[] nu1 = new double[m];
        double[] nu2 = new double[m];
        
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                xki[k][i] = Math.pow((lambda*Math.pow(theta[k][i][0], q*n*w[k][i]))/((lambda-1)*Math.pow(theta[k][i][0], q*n*w[k][i]) + 
                            Math.pow(1+(lambda-1)*(1-Math.pow(theta[k][i][0], q)), n*w[k][i])), 1.0/q);
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                xkj[k][j] = Math.pow((lambda*Math.pow(theta[k][j][0], q*n*w[k][j]))/((lambda-1)*Math.pow(theta[k][j][0], q*n*w[k][j]) + 
                            Math.pow(1+(lambda-1)*(1-Math.pow(theta[k][j][0], q)), n*w[k][j])), 1.0/q);                       
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                yki[k][i] = Math.pow((Math.pow(1 + (lambda-1)*Math.pow(theta[k][i][1], q), n*w[k][i]) - 
                                      Math.pow(1 - Math.pow(theta[k][i][1], q), n*w[k][i]))/(
                                      Math.pow(1 + (lambda-1)*Math.pow(theta[k][i][1], q), n*w[k][i]) + 
                                     (lambda-1)*Math.pow(1 - Math.pow(theta[k][i][1], q), n*w[k][i])), 1.0/q);               
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                ykj[k][j] = Math.pow((Math.pow(1 + (lambda-1)*Math.pow(theta[k][j][1], q), n*w[k][j]) - 
                                      Math.pow(1 - Math.pow(theta[k][j][1], q), n*w[k][j]))/(
                                      Math.pow(1 + (lambda-1)*Math.pow(theta[k][j][1], q), n*w[k][j]) + 
                                     (lambda-1)*Math.pow(1 - Math.pow(theta[k][j][1], q), n*w[k][j])), 1.0/q);               
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                x1ki[k][i] = Math.pow((Math.pow(1 + (lambda-1)*Math.pow(xki[k][i], q), a) - 
                                       Math.pow(1 - Math.pow(xki[k][i], q), a))/(
                                       Math.pow(1 + (lambda-1)*Math.pow(xki[k][i], q), a) + 
                                      (lambda-1)*Math.pow(1 - Math.pow(xki[k][i], q), a)), 1.0/q);                                                            
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                x1kj[k][j] = Math.pow((Math.pow(1 + (lambda-1)*Math.pow(xkj[k][j], q), b) - 
                                       Math.pow(1 - Math.pow(xkj[k][j], q), b))/(
                                       Math.pow(1 + (lambda-1)*Math.pow(xkj[k][j], q), b) + 
                                      (lambda-1)*Math.pow(1 - Math.pow(xkj[k][j], q), b)), 1.0/q);                                                            
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                y1ki[k][i] = Math.pow((lambda*Math.pow(yki[k][i], q*a))/((lambda-1)*Math.pow(yki[k][i], q*a) + 
                             Math.pow(1+(lambda-1)*(1-Math.pow(yki[k][i], q)), a)), 1.0/q);                                                            
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                y1kj[k][j] = Math.pow((lambda*Math.pow(ykj[k][j], q*b))/((lambda-1)*Math.pow(ykj[k][j], q*b) + 
                             Math.pow(1+(lambda-1)*(1-Math.pow(ykj[k][j], q)), b)), 1.0/q);                                                            
            }
        }
        for (int k = 0; k < m; k++) {
            mu1[k] = 1.0;
            mu2[k] = 1.0;
            nu1[k] = 1.0;
            nu2[k] = 1.0;
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (j != i) {
                        mu1[k] = mu1[k] * Math.pow(Math.pow((Math.pow(x1ki[k][i], q)+Math.pow(x1kj[k][j], q)-Math.pow(x1ki[k][i], q)*
                                          Math.pow(x1kj[k][j], q)-(1-lambda)*Math.pow(x1ki[k][i], q)*Math.pow(x1kj[k][j], q))/
                                         (1-(1-lambda)*Math.pow(x1ki[k][i], q)*Math.pow(x1kj[k][j], q)), 1.0/q), q/(n*(n-1)));
                        mu2[k] = mu2[k] * Math.pow(1+(lambda-1)*(1-Math.pow(Math.pow((Math.pow(x1ki[k][i], q)+Math.pow(x1kj[k][j], q)-
                                          Math.pow(x1ki[k][i], q)*Math.pow(x1kj[k][j], q)-(1-lambda)*Math.pow(x1ki[k][i], q)*
                                          Math.pow(x1kj[k][j], q))/(1-(1-lambda)*Math.pow(x1ki[k][i], q)*
                                          Math.pow(x1kj[k][j], q)), 1.0/q), q)), 1.0/(n*(n-1)));
                        nu1[k] = nu1[k] * Math.pow(1 + (lambda-1)*Math.pow(Math.pow((Math.pow(y1ki[k][i], q)*Math.pow(y1kj[k][j], q))/
                                         (lambda + (1-lambda)*(Math.pow(y1ki[k][i], q)+Math.pow(y1kj[k][j], q)-Math.pow(y1ki[k][i], q)*
                                          Math.pow(y1kj[k][j], q))), 1.0/q), q), 1.0/(n*(n-1)));
                        nu2[k] = nu2[k] * Math.pow(1 - Math.pow(Math.pow((Math.pow(y1ki[k][i], q)*Math.pow(y1kj[k][j], q))/
                                         (lambda + (1-lambda)*(Math.pow(y1ki[k][i], q)+Math.pow(y1kj[k][j], q)-Math.pow(y1ki[k][i], q)*
                                          Math.pow(y1kj[k][j], q))), 1.0/q), q), 1.0/(n*(n-1)));
                    }
                }
            }                    
            resultOfqROFWHAGBM[k][0] = Math.pow((Math.pow((lambda*lambda-1)*mu1[k]+mu2[k], 1.0/(a+b)) - 
                                                 Math.pow(mu2[k]-mu1[k], 1.0/(a+b)))/
                                                (Math.pow((lambda*lambda-1)*mu1[k]+mu2[k], 1.0/(a+b)) + 
                                                (lambda-1)*Math.pow(mu2[k]-mu1[k], 1.0/(a+b))), 1.0/q);
            resultOfqROFWHAGBM[k][1] = Math.pow((lambda*Math.pow(nu1[k]-nu2[k], 1.0/(a+b)))/
                                               ((lambda-1)*Math.pow(nu1[k]-nu2[k], 1.0/(a+b)) + 
                                                 Math.pow(nu1[k]+(lambda*lambda-1)*nu2[k], 1.0/(a+b))), 1.0/q);
        }
        return resultOfqROFWHAGBM;
    }
    
    
    public double[][] FAFWPBM(double tau, int m, int n, double q, double[][][] theta, double[][] w, double s, double t) {
        double[][] resultOfqROFWFABM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWFABM[k][r] = 0.0;
            }           
        }
        double[][] xki = new double[m][n];
        double[][] xkj = new double[m][n];
        double[][] yki = new double[m][n];
        double[][] ykj = new double[m][n];
        double[] a1 = new double[m];
        double[] b1 = new double[m];
        double[] mu1 = new double[m];
        double[] nu1 = new double[m]; 
        AMProcessSelection tempLog = new AMProcessSelection();
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                xki[k][i] = 1 - tempLog.logAnyBase(tau, 1 + 
                            Math.pow(Math.pow(tau, 1-Math.pow(theta[k][i][0], q))-1, n*w[k][i])/
                            Math.pow(tau-1, n*w[k][i]-1));              
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                xkj[k][j] = 1 - tempLog.logAnyBase(tau, 1 + 
                            Math.pow(Math.pow(tau, 1-Math.pow(theta[k][j][0], q))-1, n*w[k][j])/
                            Math.pow(tau-1, n*w[k][j]-1));              
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                yki[k][i] = 1 - tempLog.logAnyBase(tau, 1 + 
                            Math.pow(Math.pow(tau, Math.pow(theta[k][i][1], q))-1, n*w[k][i])/
                            Math.pow(tau-1, n*w[k][i]-1));              
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                ykj[k][j] = 1 - tempLog.logAnyBase(tau, 1 + 
                            Math.pow(Math.pow(tau, Math.pow(theta[k][j][1], q))-1, n*w[k][j])/
                            Math.pow(tau-1, n*w[k][j]-1));              
            }
        }
        for (int k = 0; k < m; k++) {
            a1[k] = 1.0;           
            b1[k] = 1.0;          
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (j != i) {
                        a1[k] = a1[k] * (Math.pow(tau, 1 - tempLog.logAnyBase(tau, 1 + 
                                (Math.pow(Math.pow(tau, xki[k][i]) - 1, s)*Math.pow(Math.pow(tau, xkj[k][j]) - 1, t))/
                                 Math.pow(tau-1, s+t-1))) - 1);                      
                        b1[k] = b1[k] * (Math.pow(tau, 1 - tempLog.logAnyBase(tau, 1 + 
                                (Math.pow(Math.pow(tau, yki[k][i]) - 1, s)*Math.pow(Math.pow(tau, ykj[k][j]) - 1, t))/
                                 Math.pow(tau-1, s+t-1))) - 1);                     
                    }
                }
            }
            mu1[k] = 1 - tempLog.logAnyBase(tau, 1 + Math.pow(a1[k], 1.0/(n*(n-1))));        
            nu1[k] = tempLog.logAnyBase(tau, 1 + Math.pow(b1[k], 1.0/(n*(n-1))));                   
            resultOfqROFWFABM[k][0] = Math.pow(tempLog.logAnyBase(tau, 1 + Math.pow(Math.pow(tau, mu1[k])-1, 
                                      1.0/(s+t))/Math.pow(tau-1, 1.0/(s+t)-1)), 1.0/q);
            resultOfqROFWFABM[k][1] = Math.pow(1 - tempLog.logAnyBase(tau, 1 + Math.pow(Math.pow(tau, 1-nu1[k])-1, 
                                      1.0/(s+t))/Math.pow(tau-1, 1.0/(s+t)-1)), 1.0/q);
        }
        return resultOfqROFWFABM;
    }
    
    public double[][] FAFWPGBM(double epsilon, int m, int n, double q, double[][][] theta, double[][] w, double a, double b) {
        double[][] resultOfqROFWFAGBM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWFAGBM[k][r] = 0.0;
            }           
        }
        double[][] xki = new double[m][n];
        double[][] xkj = new double[m][n];
        double[][] yki = new double[m][n];
        double[][] ykj = new double[m][n];
        double[] mu1 = new double[m];
        double[] mu2 = new double[m];
        double[] nu1 = new double[m];
        double[] nu2 = new double[m]; 
        AMProcessSelection tempLog = new AMProcessSelection();
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                xki[k][i] = Math.pow(tempLog.logAnyBase(epsilon, 1 + 
                            Math.pow(Math.pow(epsilon, Math.pow(theta[k][i][0], q))-1, n*w[k][i])/Math.pow(epsilon-1, n*w[k][i]-1)), 1.0/q);              
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                xkj[k][j] = Math.pow(tempLog.logAnyBase(epsilon, 1 + 
                            Math.pow(Math.pow(epsilon, Math.pow(theta[k][j][0], q))-1, n*w[k][j])/Math.pow(epsilon-1, n*w[k][j]-1)), 1.0/q); 
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                yki[k][i] = Math.pow(1 - tempLog.logAnyBase(epsilon, 1 + Math.pow(Math.pow(epsilon, 1-Math.pow(theta[k][i][1], q))-1, n*w[k][i])/
                            Math.pow(epsilon-1, n*w[k][i]-1)), 1.0/q); 
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                ykj[k][j] = Math.pow(1 - tempLog.logAnyBase(epsilon, 1 + Math.pow(Math.pow(epsilon, 1-Math.pow(theta[k][j][1], q))-1, n*w[k][j])/
                            Math.pow(epsilon-1, n*w[k][j]-1)), 1.0/q);                
            }
        }              
        for (int k = 0; k < m; k++) {
            mu1[k] = 1.0;
            mu2[k] = 0.0;
            nu1[k] = 1.0;
            nu2[k] = 0.0;
        }       
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (j != i) { 
                        mu1[k] = mu1[k] * Math.pow(Math.pow(epsilon, 1 - tempLog.logAnyBase(epsilon, 
                                 1 + Math.pow(Math.pow(epsilon, 1-xki[k][i])-1, a)*Math.pow(Math.pow(epsilon, 
                                 1 - xkj[k][j])-1, b)/Math.pow(epsilon-1, a+b-1)))-1, 1.0/(n*(n-1)));
                        nu1[k] = nu1[k] * Math.pow(Math.pow(epsilon, 1 - tempLog.logAnyBase(epsilon, 
                                 1 + Math.pow(Math.pow(epsilon, yki[k][i])-1, a)*Math.pow(Math.pow(epsilon, 
                                 ykj[k][j])-1, b)/Math.pow(epsilon-1, a+b-1)))-1, 1.0/(n*(n-1)));
                    }
                }
            }           
            mu2[k] = tempLog.logAnyBase(epsilon, 1+mu1[k]);
            nu2[k] = 1 - tempLog.logAnyBase(epsilon, 1+nu1[k]);
            resultOfqROFWFAGBM[k][0] = Math.pow(1 - tempLog.logAnyBase(epsilon, 1 + Math.pow(Math.pow(epsilon, 
                                       1-Math.pow(mu2[k], q))-1, 1.0/(a+b))/Math.pow(epsilon-1, 1.0/(a+b)-1)), 1.0/q);
            resultOfqROFWFAGBM[k][1] = Math.pow(tempLog.logAnyBase(epsilon, 1 + Math.pow(Math.pow(epsilon, 
                                       Math.pow(nu2[k], q))-1, 1.0/(a+b))/Math.pow(epsilon-1, 1.0/(a+b)-1)), 1.0/q);
        }
        return resultOfqROFWFAGBM; 
    }
    
    //Compute the log value of any base
    public double logAnyBase(double base, double value) {
        return Math.log(value)/Math.log(base);
    }
    
    //Define a function to sort the aggregation results
    public double[] SelectionSort(double[] domOfWFAGBM) {
        double[] tempArray = new double[domOfWFAGBM.length];
        for (int k=0; k<domOfWFAGBM.length; k++) {
            tempArray[k] = domOfWFAGBM[k];
        }     
        for (int i = 0; i < tempArray.length-1; i++) {
            int indexOfMax = i;
            for (int j = i+1; j < tempArray.length; j++) {
                if (tempArray[indexOfMax] < tempArray[j]) {
                    indexOfMax = j;
                }
            }
            if (indexOfMax != i) {
                double temp = tempArray[i];
                tempArray[i] = tempArray[indexOfMax];
                tempArray[indexOfMax] = temp;
            }
        }    
        return tempArray;
    }
    
    public static double distanceValue(double mu1, double mu2) {
        double distanceValue = 0.0;
        distanceValue = Math.pow(Math.pow(Math.abs(mu1-mu2), 2.0), 1.0/2.0);       
        return distanceValue;
    }
    
    public double[] getScoreValue(int m, double alpha, double[][] bm, double[][] gbm) {
        double[] scoreValue = new double[m];
        for (int k = 0; k < m; k++) {
            scoreValue[k] = alpha*bm[k][0] + (1.0-alpha)*gbm[k][0];
        }
        return scoreValue;
    }
    
    public double[] getDegreeOfMembership(int m, double[][] theta) {
        double[] scoreValue = new double[m];
        for (int k = 0; k < m; k++) {
            scoreValue[k] = theta[k][0];
        }
        return scoreValue;
    }
    
    public double[][] FAHWBM(double delta, int m, int n, double q, double[][][] theta, double[] w, double s, double t) {
        double[][] resultOfqROFWHABM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWHABM[k][r] = 0.0;
            }           
        }
        double[][] xki = new double[m][n];
        double[][] xkj = new double[m][n];
        double[][] yki = new double[m][n];
        double[][] ykj = new double[m][n];
        double[] a1 = new double[m];
        double[] a2 = new double[m];
        double[] b1 = new double[m];
        double[] b2 = new double[m];
        double[] mu1 = new double[m];
        double[] mu2 = new double[m];
        double[] nu1 = new double[m];
        double[] nu2 = new double[m];
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                xki[k][i] = (delta*Math.pow((Math.pow(1+(delta-1)*Math.pow(theta[k][i][0],q), n*w[i]) - 
                                   Math.pow(1-Math.pow(theta[k][i][0],q), n*w[i])) /
                                  (Math.pow(1+(delta-1)*Math.pow(theta[k][i][0],q), n*w[i]) + 
                            (delta-1)*Math.pow(1-Math.pow(theta[k][i][0],q), n*w[i])), s)) / 
                          (((delta-1)*Math.pow((Math.pow(1+(delta-1)*Math.pow(theta[k][i][0],q), n*w[i]) - 
                                      Math.pow(1-Math.pow(theta[k][i][0],q), n*w[i])) /
                                     (Math.pow(1+(delta-1)*Math.pow(theta[k][i][0],q), n*w[i]) + 
                            (delta-1)*Math.pow(1-Math.pow(theta[k][i][0],q), n*w[i])), s)) +                      
                                      Math.pow(delta-(delta-1)*((Math.pow(1+(delta-1)*Math.pow(theta[k][i][0],q), n*w[i]) - 
                                      Math.pow(1-Math.pow(theta[k][i][0],q), n*w[i])) /                                         
                                     (Math.pow(1+(delta-1)*Math.pow(theta[k][i][0],q), n*w[i]) + 
                            (delta-1)*Math.pow(1-Math.pow(theta[k][i][0],q), n*w[i]))), s));                       
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                 xkj[k][j] = (delta*Math.pow((Math.pow(1+(delta-1)*Math.pow(theta[k][j][0],q), n*w[j]) - 
                                    Math.pow(1-Math.pow(theta[k][j][0],q), n*w[j])) /
                                   (Math.pow(1+(delta-1)*Math.pow(theta[k][j][0],q), n*w[j]) + 
                             (delta-1)*Math.pow(1-Math.pow(theta[k][j][0],q), n*w[j])), t)) / 
                           (((delta-1)*Math.pow((Math.pow(1+(delta-1)*Math.pow(theta[k][j][0],q), n*w[j]) - 
                                       Math.pow(1-Math.pow(theta[k][j][0],q), n*w[j])) /
                                      (Math.pow(1+(delta-1)*Math.pow(theta[k][j][0],q), n*w[j]) + 
                             (delta-1)*Math.pow(1-Math.pow(theta[k][j][0],q), n*w[j])), t)) +                      
                                       Math.pow(delta-(delta-1)*((Math.pow(1+(delta-1)*Math.pow(theta[k][j][0],q), n*w[j]) - 
                                       Math.pow(1-Math.pow(theta[k][j][0],q), n*w[j])) /                                         
                                      (Math.pow(1+(delta-1)*Math.pow(theta[k][j][0],q), n*w[j]) + 
                             (delta-1)*Math.pow(1-Math.pow(theta[k][j][0],q), n*w[j]))), t));                       
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                yki[k][i] = (Math.pow((1 + (delta-1)*((delta*Math.pow(theta[k][i][1],n*w[i]))/
                            ((delta-1)*Math.pow(theta[k][i][1],q*n*w[i]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][i][1], q)), n*w[i])))), s) - 
                             Math.pow(1-((delta*Math.pow(theta[k][i][1],n*w[i]))/((delta-1)*
                             Math.pow(theta[k][i][1],q*n*w[i]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][i][1], q)), n*w[i]))), s)) /
                            (Math.pow((1 + ((delta-1)*((delta*Math.pow(theta[k][i][1],n*w[i]))/
                            ((delta-1)*Math.pow(theta[k][i][1],q*n*w[i]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][i][1], q)), n*w[i]))))), s) + 
                            (delta-1)*Math.pow(1-(delta*Math.pow(theta[k][i][1],n*w[i]))/(((delta-1)*
                             Math.pow(theta[k][i][1],q*n*w[i]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][i][1], q)), n*w[i]))), s));               
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                ykj[k][j] = (Math.pow((1 + (delta-1)*((delta*Math.pow(theta[k][j][1],n*w[j]))/
                            ((delta-1)*Math.pow(theta[k][j][1],q*n*w[j]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][j][1], q)), n*w[j])))), t) - 
                             Math.pow(1-((delta*Math.pow(theta[k][j][1],n*w[j]))/((delta-1)*
                             Math.pow(theta[k][j][1],q*n*w[j]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][j][1], q)), n*w[j]))), t)) /
                            (Math.pow((1 + ((delta-1)*((delta*Math.pow(theta[k][j][1],n*w[j]))/
                            ((delta-1)*Math.pow(theta[k][j][1],q*n*w[j]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][j][1], q)), n*w[j]))))), t) + 
                            (delta-1)*Math.pow(1-(delta*Math.pow(theta[k][j][1],n*w[j]))/(((delta-1)*
                             Math.pow(theta[k][j][1],q*n*w[j]) + Math.pow(1+(delta-1)*
                            (1-Math.pow(theta[k][j][1], q)), n*w[j]))), t));               
            }
        }
        for (int k = 0; k < m; k++) {
            a1[k] = 1.0;
            a2[k] = 1.0;
            b1[k] = 1.0;
            b2[k] = 1.0;
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (j != i) {
                        a1[k] = a1[k] * (1 + (delta-1)*((xki[k][i]*xkj[k][j])/(delta+(1-delta)*(xki[k][i]+xkj[k][j]-xki[k][i]*xkj[k][j]))));
                        a2[k] = a2[k] * (1 - ((xki[k][i]*xkj[k][j])/(delta+(1-delta)*(xki[k][i]+xkj[k][j]-xki[k][i]*xkj[k][j]))));
                        b1[k] = b1[k] * ((yki[k][i]+ykj[k][j]+(delta-2)*yki[k][i]*ykj[k][j])/(1-(1-delta)*yki[k][i]*ykj[k][j]));
                        b2[k] = b2[k] * (delta-(delta-1)*((yki[k][i]+ykj[k][j]+(delta-2)*yki[k][i]*ykj[k][j])/(1-(1-delta)*yki[k][i]*ykj[k][j])));
                    }
                }
            }
            mu1[k] = Math.pow(1 + (delta-1)*((a1[k]-a2[k])/(a1[k]+(delta-1)*a2[k])), 1.0/(n*(n-1)));
            mu2[k] = Math.pow(1 - (a1[k]-a2[k])/(a1[k]+(delta-1)*a2[k]), 1.0/(n*(n-1)));
            nu1[k] = Math.pow((delta*b1[k])/((delta-1)*b1[k]+b2[k]), 1.0/(n*(n-1)));
            nu2[k] = Math.pow(delta - (delta-1)*((delta*b1[k])/((delta-1)*b1[k]+b2[k])), 1.0/(n*(n-1)));           
            resultOfqROFWHABM[k][0] = Math.pow((delta*Math.pow((mu1[k]-mu2[k])/(mu1[k]+(delta-1)*mu2[k]), 1.0/(s+t)))/
                                     ((delta-1)*Math.pow((mu1[k]-mu2[k])/(mu1[k]+(delta-1)*mu2[k]), 1.0/(s+t))+
                                      Math.pow(delta-(delta-1)*((mu1[k]-mu2[k])/(mu1[k]+(delta-1)*mu2[k])), 1.0/(s+t))), 1.0/q);
            resultOfqROFWHABM[k][1] = Math.pow((Math.pow(1 + (delta-1)*((delta*nu1[k])/((delta-1)*nu1[k]+nu2[k])), 1.0/(s+t)) - 
                                      Math.pow(1 - (delta*nu1[k])/((delta-1)*nu1[k]+nu2[k]), 1.0/(s+t)))/
                                     (Math.pow(1 + (delta-1)*((delta*nu1[k])/((delta-1)*nu1[k]+nu2[k])), 1.0/(s+t)) + 
                                     (delta-1)*Math.pow(1 - (delta*nu1[k])/((delta-1)*nu1[k]+nu2[k]), 1.0/(s+t))), 1.0/q);
        }
        return resultOfqROFWHABM;
    }
    
    public double[][] FAHWGBM(double lambda, int m, int n, double q, double[][][] theta, double[] w, double a, double b) {
        double[][] resultOfqROFWHAGBM = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWHAGBM[k][r] = 0.0;
            }           
        }
        double[][] xki = new double[m][n];
        double[][] xkj = new double[m][n];
        double[][] yki = new double[m][n];
        double[][] ykj = new double[m][n];
        double[][] x1ki = new double[m][n];
        double[][] x1kj = new double[m][n];
        double[][] y1ki = new double[m][n];
        double[][] y1kj = new double[m][n];
        double[] mu1 = new double[m];
        double[] mu2 = new double[m];
        double[] nu1 = new double[m];
        double[] nu2 = new double[m];
        
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                xki[k][i] = Math.pow((lambda*Math.pow(theta[k][i][0], q*n*w[i]))/((lambda-1)*Math.pow(theta[k][i][0], q*n*w[i]) + 
                            Math.pow(1+(lambda-1)*(1-Math.pow(theta[k][i][0], q)), n*w[i])), 1.0/q);
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                xkj[k][j] = Math.pow((lambda*Math.pow(theta[k][j][0], q*n*w[j]))/((lambda-1)*Math.pow(theta[k][j][0], q*n*w[j]) + 
                            Math.pow(1+(lambda-1)*(1-Math.pow(theta[k][j][0], q)), n*w[j])), 1.0/q);                       
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                yki[k][i] = Math.pow((Math.pow(1 + (lambda-1)*Math.pow(theta[k][i][1], q), n*w[i]) - 
                                      Math.pow(1 - Math.pow(theta[k][i][1], q), n*w[i]))/(
                                      Math.pow(1 + (lambda-1)*Math.pow(theta[k][i][1], q), n*w[i]) + 
                                     (lambda-1)*Math.pow(1 - Math.pow(theta[k][i][1], q), n*w[i])), 1.0/q);               
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                ykj[k][j] = Math.pow((Math.pow(1 + (lambda-1)*Math.pow(theta[k][j][1], q), n*w[j]) - 
                                      Math.pow(1 - Math.pow(theta[k][j][1], q), n*w[j]))/(
                                      Math.pow(1 + (lambda-1)*Math.pow(theta[k][j][1], q), n*w[j]) + 
                                     (lambda-1)*Math.pow(1 - Math.pow(theta[k][j][1], q), n*w[j])), 1.0/q);               
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                x1ki[k][i] = Math.pow((Math.pow(1 + (lambda-1)*Math.pow(xki[k][i], q), a) - 
                                       Math.pow(1 - Math.pow(xki[k][i], q), a))/(
                                       Math.pow(1 + (lambda-1)*Math.pow(xki[k][i], q), a) + 
                                      (lambda-1)*Math.pow(1 - Math.pow(xki[k][i], q), a)), 1.0/q);                                                            
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                x1kj[k][j] = Math.pow((Math.pow(1 + (lambda-1)*Math.pow(xkj[k][j], q), b) - 
                                       Math.pow(1 - Math.pow(xkj[k][j], q), b))/(
                                       Math.pow(1 + (lambda-1)*Math.pow(xkj[k][j], q), b) + 
                                      (lambda-1)*Math.pow(1 - Math.pow(xkj[k][j], q), b)), 1.0/q);                                                            
            }
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                y1ki[k][i] = Math.pow((lambda*Math.pow(yki[k][i], q*a))/((lambda-1)*Math.pow(yki[k][i], q*a) + 
                             Math.pow(1+(lambda-1)*(1-Math.pow(yki[k][i], q)), a)), 1.0/q);                                                            
            }
        }
        for (int k = 0; k < m; k++) {
            for (int j = 0; j < n; j++) {
                y1kj[k][j] = Math.pow((lambda*Math.pow(ykj[k][j], q*b))/((lambda-1)*Math.pow(ykj[k][j], q*b) + 
                             Math.pow(1+(lambda-1)*(1-Math.pow(ykj[k][j], q)), b)), 1.0/q);                                                            
            }
        }
        for (int k = 0; k < m; k++) {
            mu1[k] = 1.0;
            mu2[k] = 1.0;
            nu1[k] = 1.0;
            nu2[k] = 1.0;
        }
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (j != i) {
                        mu1[k] = mu1[k] * Math.pow(Math.pow((Math.pow(x1ki[k][i], q)+Math.pow(x1kj[k][j], q)-Math.pow(x1ki[k][i], q)*
                                          Math.pow(x1kj[k][j], q)-(1-lambda)*Math.pow(x1ki[k][i], q)*Math.pow(x1kj[k][j], q))/
                                         (1-(1-lambda)*Math.pow(x1ki[k][i], q)*Math.pow(x1kj[k][j], q)), 1.0/q), q/(n*(n-1)));
                        mu2[k] = mu2[k] * Math.pow(1+(lambda-1)*(1-Math.pow(Math.pow((Math.pow(x1ki[k][i], q)+Math.pow(x1kj[k][j], q)-
                                          Math.pow(x1ki[k][i], q)*Math.pow(x1kj[k][j], q)-(1-lambda)*Math.pow(x1ki[k][i], q)*
                                          Math.pow(x1kj[k][j], q))/(1-(1-lambda)*Math.pow(x1ki[k][i], q)*
                                          Math.pow(x1kj[k][j], q)), 1.0/q), q)), 1.0/(n*(n-1)));
                        nu1[k] = nu1[k] * Math.pow(1 + (lambda-1)*Math.pow(Math.pow((Math.pow(y1ki[k][i], q)*Math.pow(y1kj[k][j], q))/
                                         (lambda + (1-lambda)*(Math.pow(y1ki[k][i], q)+Math.pow(y1kj[k][j], q)-Math.pow(y1ki[k][i], q)*
                                          Math.pow(y1kj[k][j], q))), 1.0/q), q), 1.0/(n*(n-1)));
                        nu2[k] = nu2[k] * Math.pow(1 - Math.pow(Math.pow((Math.pow(y1ki[k][i], q)*Math.pow(y1kj[k][j], q))/
                                         (lambda + (1-lambda)*(Math.pow(y1ki[k][i], q)+Math.pow(y1kj[k][j], q)-Math.pow(y1ki[k][i], q)*
                                          Math.pow(y1kj[k][j], q))), 1.0/q), q), 1.0/(n*(n-1)));
                    }
                }
            }                    
            resultOfqROFWHAGBM[k][0] = Math.pow((Math.pow((lambda*lambda-1)*mu1[k]+mu2[k], 1.0/(a+b)) - 
                                                 Math.pow(mu2[k]-mu1[k], 1.0/(a+b)))/
                                                (Math.pow((lambda*lambda-1)*mu1[k]+mu2[k], 1.0/(a+b)) + 
                                                (lambda-1)*Math.pow(mu2[k]-mu1[k], 1.0/(a+b))), 1.0/q);
            resultOfqROFWHAGBM[k][1] = Math.pow((lambda*Math.pow(nu1[k]-nu2[k], 1.0/(a+b)))/
                                               ((lambda-1)*Math.pow(nu1[k]-nu2[k], 1.0/(a+b)) + 
                                                 Math.pow(nu1[k]+(lambda*lambda-1)*nu2[k], 1.0/(a+b))), 1.0/q);
        }
        return resultOfqROFWHAGBM;
    }
}